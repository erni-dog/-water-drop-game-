@echo off
chcp 65001 >nul
echo ========================================
echo    🎮 小水滴勇闯沙漠游戏 - 安装脚本
echo ========================================
echo.

REM 检查 Node.js 是否安装
echo [1/5] 检查 Node.js 安装...
node --version >nul 2>&1
if errorlevel 1 (
    echo ❌ 未检测到 Node.js
    echo.
    echo 请先安装 Node.js:
    echo 1. 访问 https://nodejs.org
    echo 2. 下载 LTS 版本（推荐 20.x）
    echo 3. 双击安装包，一直点击"下一步"
    echo.
    pause
    exit /b 1
)

for /f "tokens=*" %%i in ('node --version') do set NODE_VER=%%i
echo ✓ Node.js 版本: %NODE_VER%
echo.

REM 检查 pnpm 是否安装
echo [2/5] 检查 pnpm 安装...
pnpm --version >nul 2>&1
if errorlevel 1 (
    echo pnpm 未安装，正在安装...
    call npm install -g pnpm
    if errorlevel 1 (
        echo ❌ pnpm 安装失败
        pause
        exit /b 1
    )
)

for /f "tokens=*" %%i in ('pnpm --version') do set PNPM_VER=%%i
echo ✓ pnpm 版本: %PNPM_VER%
echo.

REM 安装依赖
echo [3/5] 正在安装游戏依赖...
echo 这可能需要 1-3 分钟，请耐心等待...
echo.
call pnpm install
if errorlevel 1 (
    echo.
    echo ❌ 依赖安装失败
    echo 请检查网络连接后重试
    pause
    exit /b 1
)
echo.
echo ✓ 依赖安装完成
echo.

REM 构建
echo [4/5] 正在构建游戏...
echo 这可能需要 10-20 秒...
echo.
call pnpm build
if errorlevel 1 (
    echo.
    echo ❌ 构建失败
    echo 请尝试删除 .next 文件夹后重试
    pause
    exit /b 1
)
echo.
echo ✓ 构建完成
echo.

REM 启动游戏
echo [5/5] 正在启动游戏...
echo.
echo ========================================
echo 🎉 安装成功！
echo ========================================
echo.
echo 游戏已在后台运行
echo 请在浏览器中访问: http://localhost:5000
echo.
echo 提示:
echo - 使用 Ctrl+C 停止游戏
echo - 关闭命令行窗口会停止游戏
echo.
echo 按任意键打开游戏...
echo.
pause >nul

REM 尝试自动打开浏览器
start http://localhost:5000

REM 启动游戏
echo.
echo 正在启动游戏服务器...
echo.
call pnpm start

pause
