# 🎮 小水滴勇闯沙漠游戏 - 下载安装指南

## 📦 方法一：下载压缩包安装

### 第一步：下载游戏压缩包

游戏文件已打包为：`water-drop-game.tar.gz`（大小：7.5MB）

**下载方式：**

如果您的游戏在服务器上，可以通过以下方式下载：

1. **直接下载（如果有下载链接）**
   - 点击下载按钮获取 `water-drop-game.tar.gz`
   - 保存到任意位置

2. **通过服务器下载**
   ```bash
   # 在服务器上，将压缩包复制到可下载的目录
   cp water-drop-game.tar.gz /var/www/html/downloads/
   
   # 然后通过浏览器访问：
   # http://你的服务器IP/downloads/water-drop-game.tar.gz
   ```

3. **使用 SCP 命令（技术用户）**
   ```bash
   # 从服务器下载到本地
   scp 用户名@服务器IP:/workspace/projects/water-drop-game.tar.gz ./
   ```

---

### 第二步：解压压缩包

#### Windows 用户：
- 使用 7-Zip、WinRAR 或其他解压软件
- 右键点击 `water-drop-game.tar.gz`
- 选择 "解压到当前文件夹" 或 "提取到..."
- 解压后会得到 `water-drop-game` 文件夹

#### Mac/Linux 用户：
```bash
# 解压
tar -xzf water-drop-game.tar.gz

# 或使用解压软件
```

---

### 第三步：安装依赖

#### 1. 安装 Node.js

**必须先安装 Node.js（版本 18 或更高）**

**Windows：**
1. 访问：https://nodejs.org
2. 下载 "LTS" 版本（推荐 20.x）
3. 双击安装包，一直点击"下一步"
4. 安装完成后，打开命令行（cmd 或 PowerShell）
5. 验证安装：
   ```bash
   node --version
   npm --version
   ```

**Mac：**
```bash
# 使用 Homebrew 安装
brew install node

# 验证安装
node --version
npm --version
```

**Linux (Ubuntu/Debian)：**
```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# 验证安装
node --version
npm --version
```

---

#### 2. 安装 pnpm 包管理器

打开命令行，执行：
```bash
npm install -g pnpm
```

验证安装：
```bash
pnpm --version
```

---

### 第四步：安装游戏依赖

```bash
# 进入游戏目录
cd water-drop-game

# 安装依赖（这会下载所有需要的包，约 1-3 分钟）
pnpm install
```

**注意：** 如果安装失败，可以尝试：
```bash
# 清理缓存重试
pnpm store prune
pnpm install
```

---

### 第五步：启动游戏

#### 方式 A：前台运行（测试用）
```bash
# 构建并启动
pnpm build && pnpm start
```

启动后，打开浏览器访问：**http://localhost:5000**

#### 方式 B：后台运行（推荐）
```bash
# 安装 PM2 进程管理器
pnpm install -g pm2

# 启动游戏
pm2 start "pnpm start" --name water-drop-game

# 查看运行状态
pm2 status

# 查看日志
pm2 logs water-drop-game

# 重启游戏
pm2 restart water-drop-game

# 停止游戏
pm2 stop water-drop-game
```

---

### 第六步：访问游戏

打开浏览器，访问：

**http://localhost:5000**

游戏页面说明：
- 🏠 **首页**：游戏介绍和开始按钮
- 🔐 **登录页**：输入昵称登录
- 🎯 **关卡选择**：选择要挑战的关卡（1-8关）
- 🎮 **游戏关卡**：回答科学题目
- 🏆 **通关页面**：查看成就和统计

---

## 🔧 常见问题

### 问题 1：Node.js 版本太低

**错误提示：** `ERROR: Node.js version is too old`

**解决方法：**
- 访问 https://nodejs.org
- 下载最新的 LTS 版本（18.x 或 20.x）

---

### 问题 2：端口被占用

**错误提示：** `Error: listen EADDRINUSE: address already in use :::5000`

**解决方法：**

**Windows：**
```bash
# 查找占用 5000 端口的进程
netstat -ano | findstr :5000

# 结束进程（替换 PID 为上面的进程 ID）
taskkill /PID 进程ID /F
```

**Mac/Linux：**
```bash
# 查找并结束进程
lsof -ti:5000 | xargs kill -9

# 或使用其他端口启动
PORT=3000 pnpm start
```

---

### 问题 3：依赖安装失败

**解决方法：**
```bash
# 删除 node_modules 和 pnpm-lock.yaml
rm -rf node_modules pnpm-lock.yaml

# 重新安装
pnpm install
```

---

### 问题 4：构建失败

**解决方法：**
```bash
# 清理构建缓存
rm -rf .next

# 重新构建
pnpm build
```

---

### 问题 5：访问时页面空白

**解决方法：**
1. 检查控制台是否报错（按 F12 打开开发者工具）
2. 查看日志：
   ```bash
   pm2 logs water-drop-game
   ```
3. 确保游戏已启动：
   ```bash
   pm2 status
   ```

---

## 🚀 一键安装脚本

### Windows 用户

创建一个 `install.bat` 文件，内容如下：

```batch
@echo off
echo 正在安装小水滴勇闯沙漠游戏...
echo.

REM 检查 Node.js 是否安装
node --version >nul 2>&1
if errorlevel 1 (
    echo [错误] 未检测到 Node.js
    echo 请先安装 Node.js: https://nodejs.org
    pause
    exit /b 1
)

REM 安装 pnpm
echo [1/4] 正在安装 pnpm...
call npm install -g pnpm

REM 安装依赖
echo [2/4] 正在安装游戏依赖...
call pnpm install

REM 构建
echo [3/4] 正在构建游戏...
call pnpm build

REM 启动游戏
echo [4/4] 正在启动游戏...
echo.
echo 游戏启动成功！
echo 请在浏览器中访问: http://localhost:5000
echo.
echo 按 Ctrl+C 停止游戏
echo.

call pnpm start
```

**使用方法：**
1. 右键点击 `install.bat`
2. 选择 "以管理员身份运行"
3. 等待安装完成

---

### Mac/Linux 用户

创建一个 `install.sh` 文件，内容如下：

```bash
#!/bin/bash

echo "🎮 正在安装小水滴勇闯沙漠游戏..."
echo ""

# 检查 Node.js
if ! command -v node &> /dev/null; then
    echo "❌ 未检测到 Node.js"
    echo "请先安装 Node.js: https://nodejs.org"
    exit 1
fi

echo "✓ Node.js 版本: $(node --version)"
echo ""

# 安装 pnpm
echo "[1/4] 正在安装 pnpm..."
npm install -g pnpm

# 安装依赖
echo "[2/4] 正在安装游戏依赖..."
pnpm install

# 构建
echo "[3/4] 正在构建游戏..."
pnpm build

# 启动游戏
echo "[4/4] 正在启动游戏..."
echo ""
echo "🎉 游戏启动成功！"
echo "请在浏览器中访问: http://localhost:5000"
echo ""
echo "按 Ctrl+C 停止游戏"
echo ""

pnpm start
```

**使用方法：**
```bash
chmod +x install.sh
./install.sh
```

---

## 📊 系统要求

| 组件 | 最低要求 | 推荐配置 |
|------|---------|---------|
| Node.js | 18.x | 20.x LTS |
| 内存 | 2GB | 4GB 以上 |
| 磁盘空间 | 1GB | 2GB 以上 |
| 操作系统 | Windows 10+ | Windows 11 |
| 操作系统 | macOS 10.15+ | macOS 13+ |
| 操作系统 | Ubuntu 18.04+ | Ubuntu 22.04+ |
| 浏览器 | Chrome 90+ | Chrome 120+ |

---

## 🎯 快速开始

如果您已经熟悉命令行，可以快速执行：

```bash
# Windows
pnpm install && pnpm build && pnpm start

# Mac/Linux
pnpm install && pnpm build && pnpm start
```

然后访问：**http://localhost:5000**

---

## 📖 游戏说明

**游戏特色：**
- 8 个科学知识关卡
- 趣味选择题，寓教于乐
- 帮助小水滴将沙漠变成绿洲
- 通关后查看成就和统计

**知识点：**
- 水的三态变化
- 溶解现象
- 水的净化
- 水的循环

---

## 💡 提示

- 首次运行需要构建，请耐心等待 1-2 分钟
- 如果遇到问题，查看上面的常见问题部分
- 推荐使用 Chrome 浏览器获得最佳体验
- 游戏支持响应式设计，可在手机和平板上运行

---

## 📞 获取帮助

如果遇到其他问题：
1. 查看 `EXPORT_GUIDE.md` 获取详细说明
2. 查看 `SIMPLE_GUIDE.md` 获取简单教程
3. 检查游戏日志：
   ```bash
   pm2 logs water-drop-game
   ```

---

**祝您游戏愉快！** 🎮✨
