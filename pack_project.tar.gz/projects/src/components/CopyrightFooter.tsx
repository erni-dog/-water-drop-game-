'use client';

import { Droplet, Heart, Shield } from 'lucide-react';

export default function CopyrightFooter() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gradient-to-r from-blue-600 to-green-600 text-white py-8 mt-auto">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          {/* 作者信息 */}
          <div className="text-center mb-6">
            <div className="flex items-center justify-center gap-2 mb-4">
              <Droplet className="w-6 h-6" />
              <h3 className="text-xl font-bold">小水滴勇闯沙漠</h3>
            </div>
            <p className="text-blue-100 text-sm">
              基于教科版科学三年级课程设计的互动教育游戏
            </p>
          </div>

          {/* 版权声明 */}
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 mb-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
              {/* 版权年份 */}
              <div className="flex flex-col items-center gap-2">
                <Shield className="w-5 h-5 text-blue-200" />
                <div>
                  <p className="font-semibold">版权所有</p>
                  <p className="text-sm text-blue-100">
                    © {currentYear} 作者保留所有权利
                  </p>
                </div>
              </div>

              {/* 许可协议 */}
              <div className="flex flex-col items-center gap-2">
                <Heart className="w-5 h-5 text-pink-200" />
                <div>
                  <p className="font-semibold">许可协议</p>
                  <p className="text-sm text-blue-100">
                    CC BY-NC-SA 4.0
                  </p>
                </div>
              </div>

              {/* 版本信息 */}
              <div className="flex flex-col items-center gap-2">
                <Droplet className="w-5 h-5 text-green-200" />
                <div>
                  <p className="font-semibold">当前版本</p>
                  <p className="text-sm text-blue-100">
                    v1.0.0
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* 版权声明详情 */}
          <div className="text-center text-sm text-blue-100 leading-relaxed">
            <p className="mb-2">
              本游戏内容基于教科版科学三年级教材设计，旨在帮助学生理解水的三态变化、溶解、分离等科学知识。
            </p>
            <p>
              未经作者书面许可，禁止商业用途。如需合作或转载，请联系作者获取授权。
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
