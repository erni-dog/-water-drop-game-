'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Upload, Download, FileText, AlertCircle, CheckCircle } from 'lucide-react';
import { Question } from '@/lib/game-data';

interface QuestionImportDialogProps {
  onImport: (questions: Question[]) => void;
  levelId?: number;
}

export default function QuestionImportDialog({ onImport, levelId }: QuestionImportDialogProps) {
  const [open, setOpen] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [importResult, setImportResult] = useState<{
    success: boolean;
    message: string;
    count?: number;
  } | null>(null);

  // 下载模板
  const downloadTemplate = () => {
    const template = [
      {
        "id": 1,
        "type": "choice",
        "question": "题目内容",
        "options": ["选项A", "选项B", "选项C", "选项D"],
        "answer": "选项A",
        "explanation": "答案解析"
      },
      {
        "id": 2,
        "type": "true-false",
        "question": "判断题内容",
        "answer": "对",
        "explanation": "答案解析"
      },
      {
        "id": 3,
        "type": "fill",
        "question": "填空题内容，答案是______。",
        "options": ["答案A", "答案B", "答案C", "答案D"],
        "answer": "答案A",
        "explanation": "答案解析"
      },
      {
        "id": 4,
        "type": "experiment",
        "question": "实验题内容",
        "options": ["选项A", "选项B", "选项C", "选项D"],
        "answer": "选项A",
        "explanation": "答案解析"
      },
      {
        "id": 5,
        "type": "application",
        "question": "应用题内容",
        "options": ["选项A", "选项B", "选项C", "选项D"],
        "answer": "选项A",
        "explanation": "答案解析"
      }
    ];

    const blob = new Blob([JSON.stringify(template, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = '题库模板.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // 处理文件选择
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      setImportResult(null);
    }
  };

  // 导入题库
  const handleImport = () => {
    if (!file) {
      setImportResult({
        success: false,
        message: '请选择要导入的JSON文件'
      });
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const questions = JSON.parse(content);

        // 验证数据格式
        if (!Array.isArray(questions)) {
          throw new Error('题库数据必须是数组格式');
        }

        // 验证每道题的字段
        const validQuestions: Question[] = [];
        let errorCount = 0;

        questions.forEach((q: any, index) => {
          if (!q.id || !q.type || !q.question || !q.answer) {
            errorCount++;
            return;
          }

          validQuestions.push({
            id: q.id,
            type: q.type,
            question: q.question,
            options: q.options || [],
            answer: q.answer,
            explanation: q.explanation || ''
          });
        });

        if (validQuestions.length === 0) {
          throw new Error('没有有效的题目数据');
        }

        // 导入成功
        setImportResult({
          success: true,
          message: `成功导入 ${validQuestions.length} 道题目${errorCount > 0 ? `，${errorCount} 道题目格式错误被跳过` : ''}`,
          count: validQuestions.length
        });

        onImport(validQuestions);

        // 3秒后自动关闭
        setTimeout(() => {
          setOpen(false);
          setFile(null);
          setImportResult(null);
        }, 3000);

      } catch (error: any) {
        setImportResult({
          success: false,
          message: `导入失败：${error.message}`
        });
      }
    };

    reader.readAsText(file);
  };

  // 重置
  const reset = () => {
    setFile(null);
    setImportResult(null);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="bg-blue-500 hover:bg-blue-600 text-white border-0">
          <Upload className="w-4 h-4 mr-2" />
          导入题库
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>导入题库</DialogTitle>
          <DialogDescription>
            支持从JSON文件导入题库，请先下载模板并按照格式填写。
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* 步骤1：下载模板 */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <div className="flex-shrink-0 w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 font-bold">
                1
              </div>
              <div className="flex-1">
                <h4 className="font-semibold text-blue-900 mb-2">下载题库模板</h4>
                <p className="text-sm text-blue-700 mb-3">
                  点击下方按钮下载JSON格式的题库模板
                </p>
                <Button onClick={downloadTemplate} variant="outline" size="sm" className="bg-white hover:bg-blue-50 text-blue-600 border-blue-300">
                  <Download className="w-4 h-4 mr-2" />
                  下载题库模板
                </Button>
              </div>
            </div>
          </div>

          {/* 步骤2：编辑模板 */}
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <div className="flex-shrink-0 w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-green-600 font-bold">
                2
              </div>
              <div className="flex-1">
                <h4 className="font-semibold text-green-900 mb-2">编辑题库模板</h4>
                <p className="text-sm text-green-700">
                  使用文本编辑器（如记事本、VS Code）打开模板文件，按照格式添加或修改题目内容。
                </p>
              </div>
            </div>
          </div>

          {/* 步骤3：导入题库 */}
          <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <div className="flex-shrink-0 w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center text-purple-600 font-bold">
                3
              </div>
              <div className="flex-1">
                <h4 className="font-semibold text-purple-900 mb-2">导入题库文件</h4>
                <p className="text-sm text-purple-700 mb-3">
                  点击下方按钮选择编辑好的JSON文件进行导入
                </p>
                <div className="flex items-center gap-2">
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleFileSelect}
                    className="hidden"
                    id="file-upload"
                  />
                  <label htmlFor="file-upload">
                    <Button
                      onClick={() => document.getElementById('file-upload')?.click()}
                      variant="outline"
                      size="sm"
                      className="bg-white hover:bg-purple-50 text-purple-600 border-purple-300 cursor-pointer"
                    >
                      <FileText className="w-4 h-4 mr-2" />
                      选择文件
                    </Button>
                  </label>
                  {file && (
                    <span className="text-sm text-purple-700 font-medium">
                      {file.name}
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* 导入结果 */}
          {importResult && (
            <div className={`border rounded-lg p-4 ${
              importResult.success
                ? 'bg-green-50 border-green-200'
                : 'bg-red-50 border-red-200'
            }`}>
              <div className="flex items-start gap-3">
                {importResult.success ? (
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                )}
                <div className="flex-1">
                  <p className={`font-medium ${
                    importResult.success ? 'text-green-900' : 'text-red-900'
                  }`}>
                    {importResult.success ? '导入成功！' : '导入失败'}
                  </p>
                  <p className={`text-sm mt-1 ${
                    importResult.success ? 'text-green-700' : 'text-red-700'
                  }`}>
                    {importResult.message}
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={reset}
            disabled={!file && !importResult}
          >
            重置
          </Button>
          <Button
            onClick={handleImport}
            disabled={!file || !!importResult?.success}
            className="bg-purple-600 hover:bg-purple-700"
          >
            开始导入
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
