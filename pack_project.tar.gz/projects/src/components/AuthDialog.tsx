'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Droplet, Lock, User } from 'lucide-react';

interface AuthDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  mode?: 'login' | 'register';
  onSuccess: (user: any) => void;
}

export default function AuthDialog({ open, onOpenChange, mode = 'login', onSuccess }: AuthDialogProps) {
  const [activeTab, setActiveTab] = useState(mode === 'register' ? 'register' : 'login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (open) {
      setActiveTab(mode === 'register' ? 'register' : 'login');
    }
  }, [open, mode]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    setTimeout(() => {
      // 从 localStorage 获取用户列表
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      const foundUser = users.find((u: any) => u.username === username && u.password === password);

      if (foundUser) {
        // 保存登录状态
        const userData = {
          username: foundUser.username,
          role: foundUser.role,
          loginTime: new Date().toISOString()
        };
        localStorage.setItem('user', JSON.stringify(userData));
        onSuccess(userData);
        handleClose();
      } else {
        setError('用户名或密码错误');
      }
      setLoading(false);
    }, 800);
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    // 验证
    if (!username || !password) {
      setError('请填写所有字段');
      setLoading(false);
      return;
    }

    if (password !== confirmPassword) {
      setError('两次输入的密码不一致');
      setLoading(false);
      return;
    }

    if (password.length < 4) {
      setError('密码长度至少为4位');
      setLoading(false);
      return;
    }

    setTimeout(() => {
      // 获取现有用户列表
      const users = JSON.parse(localStorage.getItem('users') || '[]');

      // 检查用户名是否已存在
      if (users.find((u: any) => u.username === username)) {
        setError('用户名已存在');
        setLoading(false);
        return;
      }

      // 创建新用户 - 特定用户名自动获得管理员权限
      const newUser = {
        username,
        password,
        role: username === 'admin' ? 'admin' : 'student',
        createdAt: new Date().toISOString(),
        completedLevels: [],
        totalGames: 0
      };

      // 保存用户
      users.push(newUser);
      localStorage.setItem('users', JSON.stringify(users));

      // 自动登录
      const userData = {
        username: newUser.username,
        role: newUser.role,
        loginTime: new Date().toISOString()
      };
      localStorage.setItem('user', JSON.stringify(userData));
      onSuccess(userData);
      handleClose();
    }, 800);
  };

  const handleClose = () => {
    setUsername('');
    setPassword('');
    setConfirmPassword('');
    setError('');
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-400 to-blue-500 rounded-full flex items-center justify-center shadow-lg">
              <Droplet className="w-8 h-8 text-white" />
            </div>
          </div>
          <DialogTitle className="text-2xl font-bold text-center">
            {activeTab === 'login' ? '登录' : '注册'}
          </DialogTitle>
          <DialogDescription className="text-center">
            {activeTab === 'login' ? '登录你的账号开始游戏' : '创建新账号开始冒险'}
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="login" className="text-base">登录</TabsTrigger>
            <TabsTrigger value="register" className="text-base">注册</TabsTrigger>
          </TabsList>

          {/* 登录表单 */}
          <TabsContent value="login">
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username" className="text-sm font-medium flex items-center gap-2">
                  <User className="w-4 h-4" />
                  用户名
                </Label>
                <Input
                  id="username"
                  type="text"
                  placeholder="请输入用户名"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="h-11"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-sm font-medium flex items-center gap-2">
                  <Lock className="w-4 h-4" />
                  密码
                </Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="请输入密码"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="h-11"
                  required
                />
              </div>

              {error && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-3 py-2 rounded-lg text-sm">
                  {error}
                </div>
              )}

              <Button
                type="submit"
                className="w-full h-11 text-base font-bold bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700"
                disabled={loading}
              >
                {loading ? '登录中...' : '登录'}
              </Button>
            </form>
          </TabsContent>

          {/* 注册表单 */}
          <TabsContent value="register">
            <form onSubmit={handleRegister} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="reg-username" className="text-sm font-medium flex items-center gap-2">
                  <User className="w-4 h-4" />
                  用户名
                </Label>
                <Input
                  id="reg-username"
                  type="text"
                  placeholder="请输入用户名"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="h-11"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="reg-password" className="text-sm font-medium flex items-center gap-2">
                  <Lock className="w-4 h-4" />
                  密码
                </Label>
                <Input
                  id="reg-password"
                  type="password"
                  placeholder="请输入密码（至少4位）"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="h-11"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirm-password" className="text-sm font-medium flex items-center gap-2">
                  <Lock className="w-4 h-4" />
                  确认密码
                </Label>
                <Input
                  id="confirm-password"
                  type="password"
                  placeholder="请再次输入密码"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="h-11"
                  required
                />
              </div>

              {error && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-3 py-2 rounded-lg text-sm">
                  {error}
                </div>
              )}

              <Button
                type="submit"
                className="w-full h-11 text-base font-bold bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700"
                disabled={loading}
              >
                {loading ? '注册中...' : '注册并登录'}
              </Button>
            </form>
          </TabsContent>
        </Tabs>

        <div className="text-center text-sm text-gray-500">
          <p>提示：用户名为"admin"将获得管理员权限</p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
