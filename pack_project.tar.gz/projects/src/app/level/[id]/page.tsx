'use client';

import { useRouter, useParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { ArrowLeft, TreePine, RotateCcw, CheckCircle2, XCircle, Sprout } from 'lucide-react';
import { LEVELS_DATA, Question, getLevelData } from '@/lib/game-data';
import { useEffect, useState, useRef } from 'react';

export default function LevelPage() {
  const router = useRouter();
  const params = useParams();
  const levelId = parseInt(params.id as string);
  const levelInfo = LEVELS_DATA.find(l => l.id === levelId);
  
  const [mounted, setMounted] = useState(false);
  const [level, setLevel] = useState(getLevelData(levelId));
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswer, setUserAnswer] = useState('');
  const [lives, setLives] = useState(3);
  const [treesPlanted, setTreesPlanted] = useState(0);
  const [showFeedback, setShowFeedback] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [levelCompleted, setLevelCompleted] = useState(false);
  const [shaking, setShaking] = useState(false);
  const [plantingTree, setPlantingTree] = useState(false);
  const [questionTransition, setQuestionTransition] = useState(false);
  const [shuffledOptions, setShuffledOptions] = useState<string[]>([]);
  
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    setMounted(true);
    
    // 添加自定义动画样式
    if (typeof document !== 'undefined') {
      const style = document.createElement('style');
      style.textContent = `
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          10%, 30%, 50%, 70%, 90% { transform: translateX(-10px); }
          20%, 40%, 60%, 80% { transform: translateX(10px); }
        }
        
        .animate-shake {
          animation: shake 0.5s ease-in-out;
        }
        
        @keyframes bounce-in {
          0% { transform: scale(0) rotate(-10deg); opacity: 0; }
          50% { transform: scale(1.3) rotate(5deg); opacity: 1; }
          100% { transform: scale(1) rotate(0deg); opacity: 1; }
        }
        
        .animate-bounce-in {
          animation: bounce-in 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55);
        }
      `;
      document.head.appendChild(style);
    }
    
    // 检查登录状态
    const userData = localStorage.getItem('user');
    if (!userData) {
      router.push('/login?mode=game');
      return;
    }
    const currentUser = JSON.parse(userData);
    setUser(currentUser);
    
    // 加载用户完成关卡
    try {
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      const userRecord = users.find((u: any) => u.username === currentUser.username);
      if (userRecord && userRecord.completedLevels && userRecord.completedLevels.includes(levelId)) {
        setLevelCompleted(true);
      }
    } catch (e) {
      console.error('Failed to read localStorage:', e);
    }
  }, [levelId, router]);

  useEffect(() => {
    if (showFeedback) {
      playSound(isCorrect ? 'correct' : 'wrong');
      
      if (isCorrect) {
        // 显示种树动画
        setPlantingTree(true);
        setTimeout(() => {
          setPlantingTree(false);
          setShowFeedback(false);
          if (level && currentQuestionIndex < level.questions.length - 1) {
            // 题目切换动画
            setQuestionTransition(true);
            setTimeout(() => {
              setCurrentQuestionIndex(prev => prev + 1);
              setUserAnswer('');
              setQuestionTransition(false);
            }, 300);
          } else {
            handleLevelComplete();
          }
        }, 2000);
      } else {
        setShaking(true);
        setTimeout(() => {
          setShaking(false);
        }, 500);
        
        if (lives <= 1) {
          setTimeout(() => {
            setShowFeedback(false);
            setGameOver(true);
          }, 1500);
        } else {
          setTimeout(() => {
            setShowFeedback(false);
          }, 1500);
        }
      }
    }
  }, [showFeedback, isCorrect, currentQuestionIndex, lives, level]);

  // Fisher-Yates 洗牌算法 - 打乱选项顺序
  const shuffleOptions = (options: string[]): string[] => {
    const shuffled = [...options];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  };

  // 当题目索引或关卡数据变化时，打乱选项
  useEffect(() => {
    if (level && level.questions[currentQuestionIndex]) {
      const currentQuestion = level.questions[currentQuestionIndex];

      // 判断题：如果没有options，默认提供"对"和"错"两个选项
      if (currentQuestion.type === 'true-false') {
        setShuffledOptions(['对', '错']);
      }
      // 其他题型：如果有options则打乱
      else if (currentQuestion.options && currentQuestion.options.length > 0) {
        setShuffledOptions(shuffleOptions(currentQuestion.options));
      }
      // 没有选项的题目：清空选项
      else {
        setShuffledOptions([]);
      }
    }
  }, [currentQuestionIndex, level]);

  const playSound = (type: 'correct' | 'wrong' | 'cheer') => {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    if (type === 'correct') {
      oscillator.frequency.setValueAtTime(523.25, audioContext.currentTime);
      oscillator.frequency.setValueAtTime(659.25, audioContext.currentTime + 0.1);
      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.3);
    } else if (type === 'wrong') {
      oscillator.frequency.setValueAtTime(200, audioContext.currentTime);
      gainNode.gain.setValueAtTime(0.2, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.2);
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.2);
    }
  };

  const checkAnswer = () => {
    if (!userAnswer.trim() || !level) return;
    
    const currentQuestion = level.questions[currentQuestionIndex];
    let correct = false;
    
    if (currentQuestion.type === 'true-false') {
      correct = userAnswer === currentQuestion.answer;
    } else if (currentQuestion.type === 'choice' || currentQuestion.type === 'fill' || 
               currentQuestion.type === 'experiment' || currentQuestion.type === 'data-analysis' ||
               currentQuestion.type === 'application') {
      correct = userAnswer === currentQuestion.answer;
    }
    
    setIsCorrect(correct);
    setShowFeedback(true);
    
    if (correct) {
      setTreesPlanted(prev => prev + 1);
    } else {
      setLives(prev => prev - 1);
    }
  };

  const handleLevelComplete = () => {
    setLevelCompleted(true);
    try {
      // 更新用户数据
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      const userIndex = users.findIndex((u: any) => u.username === user?.username);
      
      if (userIndex !== -1) {
        if (!users[userIndex].completedLevels.includes(levelId)) {
          users[userIndex].completedLevels.push(levelId);
        }
        users[userIndex].totalGames = (users[userIndex].totalGames || 0) + 1;
        
        // 更新总共种植的树木
        users[userIndex].totalTrees = (users[userIndex].totalTrees || 0) + treesPlanted;
        
        localStorage.setItem('users', JSON.stringify(users));
      }

      // 同时保存到全局 completedLevels（向后兼容）
      const completedLevels = JSON.parse(localStorage.getItem('completedLevels') || '[]');
      if (!completedLevels.includes(levelId)) {
        completedLevels.push(levelId);
        localStorage.setItem('completedLevels', JSON.stringify(completedLevels));
      }
      
      // 第8关完成，跳转到通关成功页面
      if (levelId === 8) {
        setTimeout(() => {
          router.push('/game-complete');
        }, 2000);
      }
    } catch (e) {
      console.error('Failed to save to localStorage:', e);
    }
    playSound('cheer');
  };

  const handleRestart = () => {
    const newLevel = getLevelData(levelId);
    if (newLevel) {
      setLevel(newLevel);
    }
    setCurrentQuestionIndex(0);
    setUserAnswer('');
    setLives(3);
    setTreesPlanted(0);
    setShowFeedback(false);
    setIsCorrect(false);
    setGameOver(false);
    setPlantingTree(false);
    setQuestionTransition(false);
    setShuffledOptions([]);
  };

  const getQuestionTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      'choice': '选择题',
      'true-false': '判断题',
      'fill': '填空题',
      'experiment': '实验题',
      'data-analysis': '数据分析题',
      'application': '应用题'
    };
    return labels[type] || '题目';
  };

  const getQuestionTypeColor = (type: string) => {
    const colors: Record<string, string> = {
      'choice': 'from-blue-500 to-blue-600',
      'true-false': 'from-purple-500 to-purple-600',
      'fill': 'from-green-500 to-green-600',
      'experiment': 'from-orange-500 to-orange-600',
      'data-analysis': 'from-pink-500 to-pink-600',
      'application': 'from-teal-500 to-teal-600'
    };
    return colors[type] || 'from-gray-500 to-gray-600';
  };

  const renderTrees = () => {
    const treeEmojis = ['🌲', '🌳', '🌴', '🌱', '🎋'];
    const trees = [];
    for (let i = 0; i < treesPlanted; i++) {
      const delay = i * 0.1;
      trees.push(
        <span 
          key={i} 
          className="text-5xl animate-bounce-in" 
          style={{ animationDelay: `${delay}s` }}
        >
          {treeEmojis[i % treeEmojis.length]}
        </span>
      );
    }
    return trees;
  };

  const renderPlantingAnimation = () => {
    if (!plantingTree) return null;
    
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
        <div className="bg-white rounded-2xl p-8 text-center animate-bounce-in">
          <div className="text-8xl mb-4 animate-pulse">💧</div>
          <div className="text-6xl mb-4">➡️</div>
          <div className="text-8xl mb-4 animate-bounce">🌱</div>
          <h3 className="text-3xl font-bold text-green-600 mb-2">太棒了！</h3>
          <p className="text-xl text-gray-700">小水滴种下了一棵树！</p>
        </div>
      </div>
    );
  };

  if (!mounted || !levelInfo) return null;

  if (levelCompleted && !gameOver) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-green-400 to-green-600 flex flex-col items-center justify-center p-4">
        <div className="text-center">
          <div className="text-8xl mb-6 animate-bounce">🎉</div>
          <h1 className="text-5xl font-bold text-white mb-4">恭喜过关！</h1>
          <p className="text-2xl text-white mb-8">沙漠变绿洲，小水滴太开心了！</p>
          <div className="bg-white/20 rounded-2xl p-6 mb-8 backdrop-blur-sm">
            <p className="text-3xl text-white font-bold mb-4">你帮助小水滴种下了 10 棵树！</p>
            <div className="flex justify-center gap-3 flex-wrap">
              {renderTrees()}
            </div>
          </div>
          <Button
            onClick={() => router.push('/level-select')}
            size="lg"
            className="bg-white text-green-600 hover:bg-gray-100 px-12 py-6 text-2xl shadow-2xl"
          >
            <TreePine className="mr-3" />
            返回关卡选择
          </Button>
        </div>
      </div>
    );
  }

  if (gameOver) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-orange-400 to-red-500 flex flex-col items-center justify-center p-4">
        <div className="text-center">
          <div className="text-8xl mb-6 animate-shake">😢</div>
          <h1 className="text-5xl font-bold text-white mb-4">挑战失败</h1>
          <p className="text-2xl text-white mb-4">沙漠太干燥，小水滴没有力气了...</p>
          <div className="text-6xl mb-8">🏜️💀🌾🏜️</div>
          <p className="text-3xl text-white font-bold mb-8 animate-pulse">再试一次吧！</p>
          <Button
            onClick={handleRestart}
            size="lg"
            className="bg-white text-orange-600 hover:bg-gray-100 px-12 py-6 text-2xl shadow-2xl"
          >
            <RotateCcw className="mr-3" />
            再次闯关
          </Button>
        </div>
      </div>
    );
  }

  const currentQuestion = level?.questions[currentQuestionIndex];
  const progress = level ? ((currentQuestionIndex) / level.questions.length) * 100 : 0;

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-300 via-yellow-200 to-orange-400 relative overflow-hidden">
      {/* 种树动画 */}
      {renderPlantingAnimation()}

      {/* 返回按钮 */}
      <div className="absolute top-6 left-6 z-20 flex gap-2">
        <Button
          onClick={() => router.push('/level-select')}
          variant="outline"
          size="sm"
          className="bg-white/90 hover:bg-white shadow-lg"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          返回
        </Button>
        <Button
          onClick={() => {
            localStorage.removeItem('user');
            router.push('/login?mode=game');
          }}
          variant="outline"
          size="sm"
          className="bg-white/90 hover:bg-white text-red-600 shadow-lg"
        >
          退出
        </Button>
      </div>

      {/* 用户信息 */}
      <div className="absolute top-6 right-6 z-20">
        <div className="bg-white/90 rounded-xl px-4 py-2 shadow-lg">
          <span className="text-orange-900 font-semibold">👤 {user?.username}</span>
        </div>
      </div>

      {/* 关卡信息 */}
      <div className="pt-24 pb-6 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-3xl md:text-4xl font-bold text-orange-900 drop-shadow-lg">
              {levelInfo?.icon} {levelInfo?.name}
            </h1>
            <div className="flex items-center gap-4">
              <div className="bg-white/90 rounded-xl px-4 py-2 shadow-lg">
                <span className="text-2xl mr-2">❤️</span>
                <span className="text-2xl font-bold text-red-600">{lives}</span>
              </div>
            </div>
          </div>
          
          {/* 进度条 */}
          <div className="bg-white/50 rounded-full h-6 overflow-hidden shadow-inner">
            <div
              className="bg-gradient-to-r from-green-400 to-green-600 h-full transition-all duration-700 flex items-center justify-end pr-2"
              style={{ width: `${progress}%` }}
            >
              <span className="text-white font-bold text-sm">{Math.round(progress)}%</span>
            </div>
          </div>
          <p className="text-center mt-3 text-orange-800 font-bold text-lg">
            第 {currentQuestionIndex + 1} 题 / 共 {level?.questions.length || 10} 题
          </p>
        </div>
      </div>

      {/* 游戏主区域 */}
      <div className="container mx-auto px-4 pb-16">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6 max-w-7xl mx-auto">
          
          {/* 左侧：当前题目 */}
          <div className="lg:col-span-3">
            <div className={`
              bg-white/90 rounded-3xl p-8 shadow-2xl backdrop-blur-sm transition-all duration-500
              ${questionTransition ? 'opacity-0 transform translate-x-full' : 'opacity-100 transform translate-x-0'}
              ${shaking ? 'animate-shake' : ''}
            `}>
              {currentQuestion && (
                <>
                  {/* 题型标签 */}
                  <div className="mb-6">
                    <span className={`
                      inline-block px-4 py-2 rounded-full text-white font-bold text-sm shadow-lg
                      bg-gradient-to-r ${getQuestionTypeColor(currentQuestion.type)}
                    `}>
                      {getQuestionTypeLabel(currentQuestion.type)}
                    </span>
                  </div>

                  {/* 题目内容 */}
                  <div className="mb-8">
                    <h2 className="text-2xl md:text-3xl font-bold text-gray-800 leading-relaxed">
                      {currentQuestion.question}
                    </h2>
                  </div>

                  {/* 答题区域 */}
                  <div className="mb-6">
                    {/* 显示选项按钮（选择题） */}
                    {shuffledOptions.length > 0 && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {shuffledOptions.map((option, i) => (
                          <button
                            key={i}
                            onClick={() => !showFeedback && setUserAnswer(option)}
                            disabled={showFeedback}
                            className={`
                              p-5 rounded-2xl text-lg font-bold transition-all duration-300
                              transform hover:scale-105 shadow-lg
                              ${userAnswer === option
                                ? `bg-gradient-to-r ${getQuestionTypeColor(currentQuestion.type)} text-white shadow-xl scale-105`
                                : 'bg-gray-100 hover:bg-gradient-to-r hover:from-blue-400 hover:to-blue-500 hover:text-white text-gray-700'
                              }
                              ${showFeedback ? 'opacity-50 cursor-not-allowed' : ''}
                            `}
                          >
                            <span className="inline-block w-8 h-8 rounded-full bg-white/30 mr-3 text-center leading-8">
                              {String.fromCharCode(65 + i)}
                            </span>
                            {option}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* 提交按钮 */}
                  {!showFeedback && (
                    <div className="flex gap-4">
                      <Button
                        onClick={checkAnswer}
                        disabled={!userAnswer.trim()}
                        size="lg"
                        className={`
                          flex-1 font-bold text-xl py-6 shadow-xl transition-all duration-300
                          ${userAnswer.trim()
                            ? 'bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white transform hover:scale-105'
                            : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                          }
                        `}
                      >
                        <Sprout className="mr-2 w-6 h-6" />
                        提交答案
                      </Button>
                    </div>
                  )}

                  {/* 反馈信息 */}
                  {showFeedback && (
                    <div className={`
                      mt-6 p-6 rounded-2xl text-center transition-all duration-500
                      ${isCorrect ? 'bg-gradient-to-r from-green-100 to-green-200' : 'bg-gradient-to-r from-red-100 to-red-200'}
                    `}>
                      <div className="flex items-center justify-center gap-3 mb-3">
                        {isCorrect ? (
                          <>
                            <CheckCircle2 className="w-8 h-8 text-green-600 animate-bounce" />
                            <span className="text-3xl font-bold text-green-800">答对了！</span>
                          </>
                        ) : (
                          <>
                            <XCircle className="w-8 h-8 text-red-600" />
                            <span className="text-3xl font-bold text-red-800">答错了</span>
                          </>
                        )}
                      </div>
                      {currentQuestion.explanation && (
                        <p className="text-lg text-gray-700 bg-white/50 rounded-xl p-4 mt-3">
                          💡 {currentQuestion.explanation}
                        </p>
                      )}
                      
                      {!isCorrect && (
                        <p className="text-lg text-red-700 font-bold mt-3">
                          剩余机会：{lives - 1} 次
                        </p>
                      )}
                    </div>
                  )}
                </>
              )}
            </div>
          </div>

          {/* 右侧：游戏场景 */}
          <div className={`
            lg:col-span-2
            bg-white/90 rounded-3xl p-6 shadow-2xl backdrop-blur-sm transition-all duration-300
            ${shaking ? 'animate-shake' : ''}
          `}>
            <h2 className="text-2xl font-bold text-orange-900 mb-4 flex items-center gap-2">
              <Sprout className="w-7 h-7 text-green-600" />
              小水滴种树
            </h2>
            
            {/* 沙漠背景 */}
            <div className="relative bg-gradient-to-b from-orange-200 via-yellow-100 to-orange-300 rounded-2xl h-72 mb-4 overflow-hidden shadow-inner">
              {/* 太阳 */}
              <div className="absolute top-4 right-4 text-5xl animate-pulse">☀️</div>
              
              {/* 云朵 */}
              <div className="absolute top-6 left-4 text-4xl opacity-70">☁️</div>
              
              {/* 沙堆 */}
              <div className="absolute bottom-0 left-0 right-0">
                <div className="flex justify-around items-end h-20">
                  {[...Array(6)].map((_, i) => (
                    <div
                      key={i}
                      className="bg-orange-400 rounded-t-full opacity-80 shadow-md"
                      style={{ width: `${35 + Math.random() * 25}px`, height: `${25 + Math.random() * 15}px` }}
                    ></div>
                  ))}
                </div>
              </div>

              {/* 已种植的树 */}
              <div className="absolute bottom-16 left-0 right-0 flex flex-wrap justify-center gap-2 px-2">
                {renderTrees()}
              </div>

              {/* 小水滴角色 */}
              <div className="absolute bottom-20 left-1/2 transform -translate-x-1/2">
                <div className="text-6xl animate-bounce">💧</div>
              </div>

              {/* 铲子 */}
              <div className="absolute bottom-4 right-4 text-3xl">⛏️</div>
              
              {/* 水桶 */}
              <div className="absolute bottom-4 left-4 text-3xl">🪣</div>
            </div>

            {/* 统计信息 */}
            <div className="bg-gradient-to-r from-blue-50 to-green-50 rounded-2xl p-4 shadow-inner mb-4">
              <div className="flex justify-between items-center mb-3">
                <span className="font-bold text-gray-700 text-lg flex items-center gap-2">
                  <TreePine className="w-5 h-5 text-green-600" />
                  已种树木
                </span>
                <span className="text-3xl font-bold text-green-600">
                  {treesPlanted} / 10
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className="bg-gradient-to-r from-green-400 to-green-600 h-3 rounded-full transition-all duration-500"
                  style={{ width: `${(treesPlanted / 10) * 100}%` }}
                ></div>
              </div>
              <div className="flex justify-between items-center mt-3">
                <span className="font-bold text-gray-700 text-lg">❤️ 剩余机会</span>
                <span className="text-3xl font-bold text-red-600">{lives}</span>
              </div>
            </div>

            {/* 题目提示 */}
            <div className="bg-gradient-to-r from-orange-50 to-yellow-50 rounded-2xl p-4 border-2 border-orange-200">
              <p className="text-base text-orange-800 font-medium leading-relaxed">
                💡 <strong>故事背景：</strong>小水滴正在努力将沙漠变成绿洲！<br/>
                每答对一道题，小水滴就能种下一棵树 🌱<br/>
                帮助小水滴种满10棵树，沙漠就会变成绿洲！
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* 装饰元素 */}
      <div className="absolute bottom-0 left-0 right-0 pointer-events-none opacity-20 z-0">
        <div className="flex justify-around text-5xl py-2">
          <span>🌵</span>
          <span>🏜️</span>
          <span>🌵</span>
          <span>☀️</span>
          <span>🌵</span>
          <span>🏜️</span>
        </div>
      </div>
    </div>
  );
}
