'use client';

import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import CopyrightFooter from '@/components/CopyrightFooter';
import { Home, RotateCcw, Trophy, Sprout, Star, TreePine } from 'lucide-react';
import { useEffect, useState } from 'react';

export default function GameCompletePage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [totalTrees, setTotalTrees] = useState(0);
  const [showForest, setShowForest] = useState(false);
  const [treesGrown, setTreesGrown] = useState(0);
  const [showStats, setShowStats] = useState(false);
  const [completedLevels, setCompletedLevels] = useState<number[]>([]);

  useEffect(() => {
    // 添加动画样式
    const style = document.createElement('style');
    style.textContent = `
      @keyframes growTree {
        0% {
          opacity: 0;
          transform: scale(0) translateY(20px);
        }
        50% {
          opacity: 0.7;
        }
        100% {
          opacity: 1;
          transform: scale(1) translateY(0);
        }
      }
      @keyframes fadeInUp {
        from {
          opacity: 0;
          transform: translateY(20px);
        }
        to {
          opacity: 1;
          transform: translateY(0);
        }
      }
    `;
    document.head.appendChild(style);

    return () => {
      document.head.removeChild(style);
    };
  }, []);

  useEffect(() => {
    // 检查登录状态
    const userData = localStorage.getItem('user');
    if (!userData) {
      router.push('/login?mode=game');
      return;
    }
    const currentUser = JSON.parse(userData);
    setUser(currentUser);

    // 计算总共种植的树木 - 直接根据完成的关卡数计算，不依赖localStorage中的totalTrees
    try {
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      const userRecord = users.find((u: any) => u.username === currentUser.username);

      let calculatedTrees = 0;
      let levelsCompleted: number[] = [];

      // 始终根据完成的关卡数计算树木数量（每关10题 = 10棵树）
      if (userRecord && userRecord.completedLevels) {
        // 去重，确保每个关卡只计算一次
        const uniqueLevels = [...new Set(userRecord.completedLevels)] as number[];
        levelsCompleted = uniqueLevels.sort((a, b) => a - b);
        calculatedTrees = levelsCompleted.length * 10;

        console.log('通关页面 - 完成的关卡:', levelsCompleted);
        console.log('通关页面 - 计算的树木数量:', calculatedTrees);

        // 更新localStorage中的totalTrees为当前正确的数量
        const updatedUsers = users.map((u: any) => {
          if (u.username === currentUser.username) {
            return { ...u, totalTrees: calculatedTrees };
          }
          return u;
        });
        localStorage.setItem('users', JSON.stringify(updatedUsers));
      }

      setTotalTrees(calculatedTrees);
      setCompletedLevels(levelsCompleted);

      // 延迟显示森林动画（确保totalTrees已设置）
      setTimeout(() => {
        setShowForest(true);
        // 逐步生长树木
        const interval = setInterval(() => {
          setTreesGrown((prev) => {
            if (prev >= calculatedTrees) {
              clearInterval(interval);
              setTimeout(() => setShowStats(true), 500);
              return prev;
            }
            return prev + 1;
          });
        }, 50); // 每50ms生长一棵树
      }, 1000);
    } catch (e) {
      console.error('Failed to read localStorage:', e);
    }
  }, [router]);

  const handleRestart = () => {
    router.push('/level-select');
  };

  const handleBackToHome = () => {
    router.push('/');
  };

  const handleResetProgress = () => {
    if (confirm('确定要重置所有游戏进度吗？这会清除您的通关记录和树木数据。')) {
      try {
        const users = JSON.parse(localStorage.getItem('users') || '[]');
        const userIndex = users.findIndex((u: any) => u.username === user?.username);

        if (userIndex !== -1) {
          users[userIndex].completedLevels = [];
          users[userIndex].totalTrees = 0;
          users[userIndex].totalGames = 0;
          localStorage.setItem('users', JSON.stringify(users));
        }

        alert('进度已重置！您可以重新开始游戏了。');
        router.push('/level-select');
      } catch (e) {
        console.error('Failed to reset progress:', e);
        alert('重置失败，请稍后再试。');
      }
    }
  };

  // 生成森林树木布局
  const generateForest = () => {
    const trees = [];
    const treeEmojis = ['🌳', '🌲', '🌴', '🎄'];
    const treePositions = [];

    // 生成随机位置
    for (let i = 0; i < totalTrees; i++) {
      trees.push({
        id: i,
        emoji: treeEmojis[Math.floor(Math.random() * treeEmojis.length)],
        x: Math.random() * 90 + 5, // 5-95%
        y: Math.random() * 80 + 10, // 10-90%
        size: Math.random() * 1.5 + 0.8, // 0.8-2.3
        delay: i * 30, // 逐步出现
      });
    }
    return trees;
  };

  const forestTrees = generateForest();

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 via-blue-50 to-amber-50 flex items-center justify-center p-4 relative overflow-hidden">
      {/* 森林生长动画区域 */}
      {showForest && (
        <div className="absolute inset-0 pointer-events-none z-0">
          <div className="absolute inset-0 bg-gradient-to-t from-green-200/30 via-transparent to-transparent"></div>
          <div className="absolute bottom-0 w-full h-1/2 bg-gradient-to-t from-amber-100/50 via-green-100/30 to-transparent"></div>
          
          {/* 树木 */}
          {forestTrees.slice(0, treesGrown).map((tree) => (
            <div
              key={tree.id}
              className="absolute animate-in"
              style={{
                left: `${tree.x}%`,
                bottom: `${tree.y}%`,
                fontSize: `${tree.size * 3}rem`,
                animation: `growTree 0.6s ease-out ${tree.delay}ms forwards`,
                opacity: 0,
                transform: 'scale(0)',
              }}
            >
              {tree.emoji}
            </div>
          ))}

          {/* 树木计数显示 */}
          <div className="absolute top-8 left-1/2 -translate-x-1/2 bg-white/90 backdrop-blur-sm rounded-full px-8 py-4 shadow-lg border-2 border-green-300">
            <div className="flex items-center gap-3">
              <span className="text-3xl">🌱</span>
              <span className="text-2xl font-bold text-green-700">
                已种植 {treesGrown} / {totalTrees} 棵树
              </span>
              <span className="text-3xl">🌳</span>
            </div>
          </div>

          {/* 动物逐渐出现 */}
          {treesGrown >= totalTrees && (
            <>
              <div className="absolute bottom-1/4 left-1/4 text-4xl animate-bounce" style={{ animationDelay: '0.5s' }}>🐇</div>
              <div className="absolute top-1/3 right-1/4 text-4xl animate-bounce" style={{ animationDelay: '1s' }}>🐦</div>
              <div className="absolute bottom-1/3 right-1/3 text-4xl animate-bounce" style={{ animationDelay: '1.5s' }}>🦋</div>
              <div className="absolute top-1/4 left-1/3 text-4xl animate-bounce" style={{ animationDelay: '2s' }}>🐿️</div>
            </>
          )}
        </div>
      )}

      {/* 主内容区域 */}
      <div
        className={`bg-white rounded-3xl shadow-2xl p-8 md:p-12 max-w-2xl w-full relative z-10 border-4 border-green-200 transition-all duration-1000 ${showStats ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
      >
        {/* 顶部装饰 */}
        <div className="flex justify-center mb-6">
          <div className="flex gap-3 text-5xl">
            <span className="animate-bounce" style={{ animationDelay: '0s' }}>🏆</span>
            <span className="animate-bounce" style={{ animationDelay: '0.2s' }}>⭐</span>
            <span className="animate-bounce" style={{ animationDelay: '0.4s' }}>🏆</span>
          </div>
        </div>

        {/* 标题 */}
        <h1 className="text-4xl md:text-5xl font-bold text-center mb-4 bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
          恭喜通关！
        </h1>
        
        <p className="text-xl text-center text-gray-700 mb-8">
          {user ? `${user.username} 同学` : '你'}已成功完成所有挑战！
        </p>

        {/* 成就统计 */}
        <div className="bg-gradient-to-r from-green-100 to-blue-100 rounded-2xl p-6 mb-8 border-2 border-green-300">
          <div className="grid grid-cols-2 gap-6">
            {/* 已完成关卡 */}
            <div className="text-center">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Trophy className="w-6 h-6 text-yellow-600" />
                <span className="text-gray-700 font-semibold">已完成关卡</span>
              </div>
              <div className="text-4xl font-bold text-green-600">
                {completedLevels.length}/8
              </div>
              {completedLevels.length < 8 && (
                <p className="text-sm text-gray-600 mt-1">
                  还需完成 {8 - completedLevels.length} 关
                </p>
              )}
            </div>

            {/* 种植树木 */}
            <div className="text-center">
              <div className="flex items-center justify-center gap-2 mb-2">
                <TreePine className="w-6 h-6 text-green-600" />
                <span className="text-gray-700 font-semibold">种植树木</span>
              </div>
              <div className="text-4xl font-bold text-green-600">{totalTrees} 棵</div>
              <p className="text-sm text-gray-600 mt-1">
                每关10题
              </p>
            </div>
          </div>

          {/* 奖励星星 */}
          <div className="mt-6 pt-6 border-t-2 border-green-200">
            <div className="flex items-center justify-center gap-2 mb-3">
              <Star className="w-6 h-6 text-yellow-500 fill-current" />
              <span className="text-gray-700 font-semibold">获得成就</span>
            </div>
            <div className="flex justify-center gap-2">
              {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
                <span key={i} className="text-4xl animate-pulse" style={{ animationDelay: `${i * 0.1}s` }}>
                  ⭐
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* 故事结局 */}
        <div className="bg-gradient-to-r from-amber-50 to-orange-50 rounded-2xl p-6 mb-8 border-2 border-amber-200">
          <div className="flex items-start gap-3">
            <span className="text-4xl">🌲</span>
            <div>
              <h3 className="text-lg font-bold text-gray-800 mb-2">奇迹发生了！</h3>
              <p className="text-gray-700 leading-relaxed">
                看那！{totalTrees} 棵树在你的帮助下茁壮成长，荒芜的沙漠已经变成了郁郁葱葱的森林！
                🐦 鸟儿在天空中歌唱，🐇 小兔子在草地上跳跃，🦋 蝴蝶在花丛中飞舞，🐿️ 松鼠在树上蹦跳。
                <br /><br />
                小水滴开心地说："谢谢你！因为你的智慧和努力，这里重新充满了生机！"
                让我们一起守护这片美丽的森林，保护水资源，保护我们的地球！💚
              </p>
            </div>
          </div>
        </div>

        {/* 按钮组 */}
        <div className="flex flex-col sm:flex-row gap-4">
          <Button
            onClick={handleBackToHome}
            size="lg"
            className="flex-1 font-bold text-xl py-6 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white shadow-xl"
          >
            <Home className="mr-2 w-6 h-6" />
            返回首页
          </Button>
          <Button
            onClick={handleRestart}
            size="lg"
            className="flex-1 font-bold text-xl py-6 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white shadow-xl"
          >
            <RotateCcw className="mr-2 w-6 h-6" />
            再次挑战
          </Button>
        </div>

        {/* 重置进度按钮 */}
        {completedLevels.length > 0 && (
          <div className="mt-4">
            <Button
              onClick={handleResetProgress}
              size="lg"
              variant="outline"
              className="w-full font-bold text-lg py-4 border-2 border-red-300 text-red-600 hover:bg-red-50 hover:border-red-400"
            >
              <RotateCcw className="mr-2 w-5 h-5" />
              重置游戏进度（清除所有记录）
            </Button>
          </div>
        )}

        {/* 底部装饰 */}
        <div className="mt-8 text-center">
          <div className="flex justify-center gap-2 text-3xl">
            <span className="animate-bounce" style={{ animationDelay: '0s' }}>🌱</span>
            <span className="animate-bounce" style={{ animationDelay: '0.1s' }}>🌿</span>
            <span className="animate-bounce" style={{ animationDelay: '0.2s' }}>🌳</span>
            <span className="animate-bounce" style={{ animationDelay: '0.3s' }}>🌲</span>
            <span className="animate-bounce" style={{ animationDelay: '0.4s' }}>🌴</span>
          </div>
        </div>
      </div>

      {/* 版权信息 */}
      <CopyrightFooter />
    </div>
  );
}
