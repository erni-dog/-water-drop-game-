'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Droplet, Users, BookOpen, LogOut, Plus, Edit, Trash2, BarChart3, Gamepad2 } from 'lucide-react';
import { Question, LEVELS_DATA, getLevelData, Level } from '@/lib/game-data';
import QuestionImportDialog from '@/components/QuestionImportDialog';

interface User {
  id: number;
  username: string;
  role: string;
  loginTime: string;
  gamesPlayed: number;
  completedLevels: number[];
}

export default function AdminPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [allQuestions, setAllQuestions] = useState<Question[]>([]);
  const [levelsData, setLevelsData] = useState<Level[]>([]);
  const [selectedLevel, setSelectedLevel] = useState<number | null>(null);
  const [isAddQuestionOpen, setIsAddQuestionOpen] = useState(false);
  const [isViewQuestionsOpen, setIsViewQuestionsOpen] = useState(false);
  const [viewingLevelId, setViewingLevelId] = useState<number | null>(null);

  useEffect(() => {
    // 检查登录状态
    const userData = localStorage.getItem('user');
    if (!userData) {
      router.push('/login?mode=admin');
      return;
    }
    
    const currentUser = JSON.parse(userData);
    
    // 检查管理员权限
    if (currentUser.role !== 'admin') {
      alert('您没有访问后台管理系统的权限，只有管理员才能访问。');
      router.push('/');
      return;
    }
    
    setUser(currentUser);

    // 加载用户数据
    const storedUsers = JSON.parse(localStorage.getItem('users') || '[]');
    const formattedUsers: User[] = storedUsers.map((u: any, index: number) => ({
      id: index + 1,
      username: u.username,
      role: u.role,
      loginTime: u.createdAt || new Date().toISOString(),
      gamesPlayed: u.totalGames || 0,
      completedLevels: u.completedLevels || []
    }));
    setUsers(formattedUsers);

    // 加载所有关卡数据（包含实际题目）
    const levels: Level[] = [];
    for (let i = 1; i <= 8; i++) {
      const levelData = getLevelData(i);
      if (levelData) {
        console.log(`关卡 ${i}: ${levelData.name}, 题目数量: ${levelData.questionBank.length}`);
        levels.push(levelData);
      }
    }
    setLevelsData(levels);

    // 加载所有题目
    const questions: Question[] = [];
    levels.forEach(level => {
      questions.push(...level.questionBank);
    });
    console.log(`总共加载 ${questions.length} 道题目`);
    setAllQuestions(questions);
  }, [router]);

  const handleLogout = () => {
    localStorage.removeItem('user');
    router.push('/login');
  };

  const handleImportQuestions = (questions: Question[], levelId?: number) => {
    if (levelId) {
      // 导入到指定关卡
      localStorage.setItem(`custom_level_${levelId}`, JSON.stringify(questions));
      alert(`成功导入 ${questions.length} 道题目到关卡 ${levelId}！`);
    } else {
      // 导入到所有关卡（按类型分配）
      const levelIds = [1, 2, 3, 4, 5, 6, 7];
      const questionsPerLevel = Math.ceil(questions.length / levelIds.length);
      
      levelIds.forEach((id, index) => {
        const start = index * questionsPerLevel;
        const end = start + questionsPerLevel;
        const levelQuestions = questions.slice(start, end);
        
        if (levelQuestions.length > 0) {
          localStorage.setItem(`custom_level_${id}`, JSON.stringify(levelQuestions));
        }
      });
      alert(`成功导入 ${questions.length} 道题目，已平均分配到 ${levelIds.length} 个关卡！`);
    }
    
    // 刷新页面以加载新题库
    window.location.reload();
  };

  if (!user) {
    return <div className="min-h-screen flex items-center justify-center">加载中...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* 顶部导航栏 */}
      <header className="bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Droplet className="w-8 h-8" />
            <h1 className="text-2xl font-bold">小水滴后台管理系统</h1>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-base">欢迎, {user.username}</span>
            <Button
              variant="outline"
              onClick={handleLogout}
              className="bg-white/20 hover:bg-white/30 text-white border-white/30"
            >
              <LogOut className="w-4 h-4 mr-2" />
              退出登录
            </Button>
          </div>
        </div>
      </header>

      {/* 主内容区域 */}
      <main className="container mx-auto px-4 py-8">
        {/* 统计卡片 */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="border-l-4 border-blue-500">
            <CardHeader className="pb-3">
              <CardDescription className="text-base">总用户数</CardDescription>
              <CardTitle className="text-3xl font-bold">{users.length}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center text-sm text-gray-600">
                <Users className="w-4 h-4 mr-2" />
                活跃用户
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-green-500">
            <CardHeader className="pb-3">
              <CardDescription className="text-base">题目总数</CardDescription>
              <CardTitle className="text-3xl font-bold">{allQuestions.length}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center text-sm text-gray-600">
                <BookOpen className="w-4 h-4 mr-2" />
                题库
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-purple-500">
            <CardHeader className="pb-3">
              <CardDescription className="text-base">游戏次数</CardDescription>
              <CardTitle className="text-3xl font-bold">
                {users.reduce((sum, u) => sum + u.gamesPlayed, 0)}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center text-sm text-gray-600">
                <Gamepad2 className="w-4 h-4 mr-2" />
                累计游戏
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-orange-500">
            <CardHeader className="pb-3">
              <CardDescription className="text-base">关卡数</CardDescription>
              <CardTitle className="text-3xl font-bold">{levelsData.length}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center text-sm text-gray-600">
                <BarChart3 className="w-4 h-4 mr-2" />
                可玩关卡
              </div>
            </CardContent>
          </Card>
        </div>

        {/* 管理功能标签页 */}
        <Tabs defaultValue="users" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="users" className="text-base">
              <Users className="w-4 h-4 mr-2" />
              用户管理
            </TabsTrigger>
            <TabsTrigger value="questions" className="text-base">
              <BookOpen className="w-4 h-4 mr-2" />
              题目管理
            </TabsTrigger>
            <TabsTrigger value="levels" className="text-base">
              <Gamepad2 className="w-4 h-4 mr-2" />
              关卡管理
            </TabsTrigger>
          </TabsList>

          {/* 用户管理 */}
          <TabsContent value="users" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>用户列表</CardTitle>
                    <CardDescription>管理系统中的所有用户</CardDescription>
                  </div>
                  <Button className="bg-blue-500 hover:bg-blue-600">
                    <Plus className="w-4 h-4 mr-2" />
                    添加用户
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-3 px-4 font-semibold">用户名</th>
                        <th className="text-left py-3 px-4 font-semibold">角色</th>
                        <th className="text-left py-3 px-4 font-semibold">游戏次数</th>
                        <th className="text-left py-3 px-4 font-semibold">完成关卡</th>
                        <th className="text-left py-3 px-4 font-semibold">最后登录</th>
                        <th className="text-left py-3 px-4 font-semibold">操作</th>
                      </tr>
                    </thead>
                    <tbody>
                      {users.map((userItem) => (
                        <tr key={userItem.id} className="border-b hover:bg-gray-50">
                          <td className="py-3 px-4">{userItem.username}</td>
                          <td className="py-3 px-4">
                            <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                              userItem.role === 'admin' ? 'bg-purple-100 text-purple-700' :
                              userItem.role === 'teacher' ? 'bg-blue-100 text-blue-700' :
                              'bg-green-100 text-green-700'
                            }`}>
                              {userItem.role === 'admin' ? '管理员' :
                               userItem.role === 'teacher' ? '教师' : '学生'}
                            </span>
                          </td>
                          <td className="py-3 px-4">{userItem.gamesPlayed}</td>
                          <td className="py-3 px-4">{userItem.completedLevels.join(', ')}</td>
                          <td className="py-3 px-4">
                            {new Date(userItem.loginTime).toLocaleDateString('zh-CN')}
                          </td>
                          <td className="py-3 px-4">
                            <div className="flex gap-2">
                              <Button variant="ghost" size="sm">
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button variant="ghost" size="sm" className="text-red-500 hover:text-red-700">
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* 题目管理 */}
          <TabsContent value="questions" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>题目列表</CardTitle>
                    <CardDescription>管理所有关卡的题目</CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <QuestionImportDialog onImport={handleImportQuestions} />
                    <Button
                      className="bg-green-500 hover:bg-green-600"
                      onClick={() => {
                        setSelectedLevel(null);
                        setIsAddQuestionOpen(true);
                      }}
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      添加题目
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 max-h-[600px] overflow-y-auto">
                  {levelsData.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      正在加载关卡数据...
                    </div>
                  ) : (
                    levelsData.map((level) => (
                      <div
                        key={level.id}
                        className="border rounded-lg p-4 cursor-pointer hover:border-blue-400 transition-colors"
                        onClick={() => {
                          setViewingLevelId(level.id);
                          setIsViewQuestionsOpen(true);
                        }}
                      >
                        <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
                          <span className="text-2xl">{level.icon}</span>
                          {level.name}
                          <span className="ml-auto bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-bold">
                            {level.questionBank.length} 道题
                          </span>
                        </h3>
                        <div className="space-y-2">
                          {level.questionBank.slice(0, 3).map((question) => (
                            <div key={question.id} className="bg-gray-50 p-3 rounded text-sm">
                              <div className="font-medium mb-1">
                                题目 {question.id}: {question.question.substring(0, 50)}...
                              </div>
                              <div className="text-gray-500 text-xs">
                                类型: {question.type} | 答案: {String(question.answer)}
                              </div>
                            </div>
                          ))}
                          {level.questionBank.length > 3 && (
                            <div className="text-sm text-gray-500 text-center py-2">
                              还有 {level.questionBank.length - 3} 道题...点击查看更多
                            </div>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* 关卡管理 */}
          <TabsContent value="levels" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>关卡管理</CardTitle>
                    <CardDescription>管理游戏关卡配置</CardDescription>
                  </div>
                  <Button
                    className="bg-purple-500 hover:bg-purple-600"
                    onClick={() => alert('添加关卡功能正在开发中')}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    添加关卡
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {levelsData.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    正在加载关卡数据...
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {levelsData.map((level) => (
                      <Card key={level.id} className="hover:shadow-lg transition-shadow">
                        <CardHeader>
                          <div className="flex items-center gap-2 mb-2">
                            <span className="text-3xl">{level.icon}</span>
                            <CardTitle className="text-lg">{level.name}</CardTitle>
                          </div>
                          <CardDescription className="flex items-center gap-2">
                            <BookOpen className="w-4 h-4 text-green-600" />
                            题目数量: <span className="font-bold text-green-700">{level.questionBank.length}</span> 道题
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            <Button
                              variant="outline"
                              size="sm"
                              className="w-full"
                              onClick={() => alert(`编辑关卡: ${level.name}\n此功能正在开发中`)}
                            >
                              <Edit className="w-4 h-4 mr-2" />
                              编辑关卡
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              className="w-full text-blue-500 hover:text-blue-700"
                              onClick={() => {
                                setViewingLevelId(level.id);
                                setIsViewQuestionsOpen(true);
                              }}
                            >
                              <BookOpen className="w-4 h-4 mr-2" />
                              管理题目
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* 查看题目详情对话框 */}
        {isViewQuestionsOpen && viewingLevelId && (
          <ViewQuestionsDialog
            isOpen={isViewQuestionsOpen}
            onClose={() => {
              setIsViewQuestionsOpen(false);
              setViewingLevelId(null);
            }}
            levelId={viewingLevelId}
          />
        )}
      </main>
    </div>
  );
}

// 查看题目详情对话框组件
function ViewQuestionsDialog({ isOpen, onClose, levelId }: { isOpen: boolean; onClose: () => void; levelId: number }) {
  const level = getLevelData(levelId);
  const [customQuestions, setCustomQuestions] = useState<Question[]>([]);

  useEffect(() => {
    if (levelId) {
      // 尝试加载自定义题库
      const customData = localStorage.getItem(`custom_level_${levelId}`);
      if (customData) {
        setCustomQuestions(JSON.parse(customData));
      }
    }
  }, [levelId]);

  if (!level) return null;

  const questions = customQuestions.length > 0 ? customQuestions : level.questionBank;

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center ${isOpen ? '' : 'hidden'}`}>
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="relative bg-white rounded-lg shadow-lg w-full max-w-4xl max-h-[80vh] overflow-hidden flex flex-col">
        <div className="flex items-center justify-between p-6 border-b">
          <div>
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <span className="text-3xl">{level.icon}</span>
              {level.name} - 题目列表
            </h2>
            <p className="text-sm text-gray-500 mt-1">
              {customQuestions.length > 0 ? '自定义题库' : '默认题库'} - 共 {questions.length} 道题
            </p>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            ✕
          </Button>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          <div className="space-y-4">
            {questions.map((question, index) => (
              <div key={question.id || index} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="bg-blue-500 text-white text-xs px-2 py-1 rounded-full">
                      {index + 1}
                    </span>
                    <span className="text-sm text-gray-600">
                      类型: {question.type}
                    </span>
                  </div>
                  <Button variant="ghost" size="sm" className="text-red-500 hover:text-red-700">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
                <p className="font-medium mb-2">{question.question}</p>
                {question.options && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {question.options.map((option, idx) => {
                      const isCorrect = Array.isArray(question.answer)
                        ? question.answer.includes(String(idx))
                        : String(question.answer) === String(idx);
                      const optionLabel = ['A', 'B', 'C', 'D', 'E', 'F'][idx as any] || `${idx + 1}`;
                      return (
                        <div
                          key={idx}
                          className={`text-sm p-2 rounded ${
                            isCorrect
                              ? 'bg-green-100 text-green-800 border border-green-300'
                              : 'bg-gray-100 text-gray-700'
                          }`}
                        >
                          {optionLabel}. {option}
                          {isCorrect && ' ✓'}
                        </div>
                      );
                    })}
                  </div>
                )}
                {!question.options && (
                  <div className="text-sm p-2 rounded bg-green-100 text-green-800 border border-green-300 mt-2">
                    答案: {String(question.answer)}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="p-6 border-t bg-gray-50 flex justify-end gap-3">
          {customQuestions.length > 0 && (
            <Button
              variant="outline"
              onClick={() => {
                if (confirm('确定要清除自定义题库，恢复默认题库吗？')) {
                  localStorage.removeItem(`custom_level_${levelId}`);
                  alert('已恢复默认题库！');
                  window.location.reload();
                }
              }}
            >
              恢复默认题库
            </Button>
          )}
          <Button onClick={onClose}>关闭</Button>
        </div>
      </div>
    </div>
  );
}
