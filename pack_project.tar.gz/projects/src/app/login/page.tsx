'use client';

import { useState, useEffect, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import CopyrightFooter from '@/components/CopyrightFooter';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Droplet, Lock, User, Gamepad2, Settings } from 'lucide-react';

function LoginFormContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const mode = searchParams.get('mode') || 'game';

  const [activeTab, setActiveTab] = useState('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    // 检查是否已登录
    const userData = localStorage.getItem('user');
    if (userData) {
      const user = JSON.parse(userData);
      if (mode === 'admin') {
        router.push('/admin');
      } else {
        router.push('/level-select');
      }
    }
  }, [router, mode]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    setTimeout(() => {
      // 从 localStorage 获取用户列表
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      const user = users.find((u: any) => u.username === username && u.password === password);

      if (user) {
        // 保存登录状态
        localStorage.setItem('user', JSON.stringify({
          username: user.username,
          role: user.role,
          loginTime: new Date().toISOString()
        }));

        // 根据模式跳转
        if (mode === 'admin') {
          router.push('/admin');
        } else {
          router.push('/level-select');
        }
      } else {
        setError('用户名或密码错误');
      }
      setLoading(false);
    }, 800);
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    // 验证
    if (!username || !password) {
      setError('请填写所有字段');
      setLoading(false);
      return;
    }

    if (password !== confirmPassword) {
      setError('两次输入的密码不一致');
      setLoading(false);
      return;
    }

    if (password.length < 4) {
      setError('密码长度至少为4位');
      setLoading(false);
      return;
    }

    setTimeout(() => {
      // 获取现有用户列表
      const users = JSON.parse(localStorage.getItem('users') || '[]');

      // 检查用户名是否已存在
      if (users.find((u: any) => u.username === username)) {
        setError('用户名已存在');
        setLoading(false);
        return;
      }

      // 创建新用户
      const newUser = {
        username,
        password,
        role: mode === 'admin' ? 'admin' : 'student',
        createdAt: new Date().toISOString(),
        completedLevels: [],
        totalGames: 0
      };

      // 保存用户
      users.push(newUser);
      localStorage.setItem('users', JSON.stringify(users));

      // 自动登录
      localStorage.setItem('user', JSON.stringify({
        username: newUser.username,
        role: newUser.role,
        loginTime: new Date().toISOString()
      }));

      // 跳转
      if (mode === 'admin') {
        router.push('/admin');
      } else {
        router.push('/level-select');
      }
    }, 800);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-400 via-blue-500 to-blue-600 flex items-center justify-center p-4 pb-0">
      {/* 背景装饰 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-10 left-10 text-8xl opacity-20 animate-float">💧</div>
        <div className="absolute top-20 right-20 text-6xl opacity-20 animate-float-delay">💧</div>
        <div className="absolute bottom-20 left-20 text-7xl opacity-20 animate-float">💧</div>
        <div className="absolute bottom-10 right-10 text-6xl opacity-20 animate-float-delay">💧</div>
      </div>

      <div className="w-full max-w-4xl flex flex-col items-center">
        <Card className="w-full max-w-md shadow-2xl relative z-10 mb-8">
        <CardHeader className="text-center pb-6">
          <div className="flex justify-center mb-4">
            <div className={`w-20 h-20 rounded-full flex items-center justify-center shadow-lg ${
              mode === 'admin' 
                ? 'bg-gradient-to-br from-purple-500 to-purple-600' 
                : 'bg-gradient-to-br from-blue-500 to-blue-600'
            }`}>
              {mode === 'admin' ? (
                <Settings className="w-12 h-12 text-white" />
              ) : (
                <Gamepad2 className="w-12 h-12 text-white" />
              )}
            </div>
          </div>
          <CardTitle className="text-3xl font-bold text-gray-800">
            {mode === 'admin' ? '后台管理' : '小水滴冒险'}
          </CardTitle>
          <CardDescription className="text-base">
            {mode === 'admin' ? '登录管理后台' : '开始你的科学冒险'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="login" className="text-base">登录</TabsTrigger>
              <TabsTrigger value="register" className="text-base">注册</TabsTrigger>
            </TabsList>

            {/* 登录表单 */}
            <TabsContent value="login">
              <form onSubmit={handleLogin} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="username" className="text-base font-medium flex items-center gap-2">
                    <User className="w-4 h-4" />
                    用户名
                  </Label>
                  <Input
                    id="username"
                    type="text"
                    placeholder="请输入用户名"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="text-base h-12"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password" className="text-base font-medium flex items-center gap-2">
                    <Lock className="w-4 h-4" />
                    密码
                  </Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="请输入密码"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="text-base h-12"
                    required
                  />
                </div>

                {error && (
                  <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
                    {error}
                  </div>
                )}

                <Button
                  type="submit"
                  className="w-full h-12 text-base font-bold bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700"
                  disabled={loading}
                >
                  {loading ? '登录中...' : '登录'}
                </Button>
              </form>
            </TabsContent>

            {/* 注册表单 */}
            <TabsContent value="register">
              <form onSubmit={handleRegister} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="reg-username" className="text-base font-medium flex items-center gap-2">
                    <User className="w-4 h-4" />
                    用户名
                  </Label>
                  <Input
                    id="reg-username"
                    type="text"
                    placeholder="请输入用户名"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="text-base h-12"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="reg-password" className="text-base font-medium flex items-center gap-2">
                    <Lock className="w-4 h-4" />
                    密码
                  </Label>
                  <Input
                    id="reg-password"
                    type="password"
                    placeholder="请输入密码（至少4位）"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="text-base h-12"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirm-password" className="text-base font-medium flex items-center gap-2">
                    <Lock className="w-4 h-4" />
                    确认密码
                  </Label>
                  <Input
                    id="confirm-password"
                    type="password"
                    placeholder="请再次输入密码"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="text-base h-12"
                    required
                  />
                </div>

                {error && (
                  <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
                    {error}
                  </div>
                )}

                <Button
                  type="submit"
                  className="w-full h-12 text-base font-bold bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700"
                  disabled={loading}
                >
                  {loading ? '注册中...' : '注册'}
                </Button>
              </form>
            </TabsContent>
          </Tabs>

          <div className="mt-6 text-center text-sm text-gray-500">
            <p>{mode === 'admin' ? '管理员登录' : '学生登录'} - 开始你的冒险！</p>
          </div>
        </CardContent>
      </Card>
      </div>

      {/* 版权信息 */}
      <CopyrightFooter />

      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-20px); }
        }
        @keyframes float-delay {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-20px); }
        }
        .animate-float {
          animation: float 3s ease-in-out infinite;
        }
        .animate-float-delay {
          animation: float-delay 4s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-gradient-to-br from-blue-400 via-blue-500 to-blue-600 flex items-center justify-center">
      <div className="text-white text-xl">加载中...</div>
    </div>}>
      <LoginFormContent />
    </Suspense>
  );
}
