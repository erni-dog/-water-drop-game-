'use client';

import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { RotateCcw, Share2, Trophy } from 'lucide-react';
import { useEffect, useState } from 'react';

export default function SuccessPage() {
  const router = useRouter();
  const [mounted, setMounted] = useState(false);
  const [confettiActive, setConfettiActive] = useState(true);

  useEffect(() => {
    setMounted(true);
    
    // 播放胜利音效
    playVictorySound();
    
    // 3秒后停止彩带效果
    const timer = setTimeout(() => {
      setConfettiActive(false);
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  const playVictorySound = () => {
    // 使用 Web Audio API 生成胜利音乐
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    
    // 简单的胜利旋律
    const melody = [
      { freq: 523.25, duration: 0.2 },  // C5
      { freq: 659.25, duration: 0.2 },  // E5
      { freq: 783.99, duration: 0.2 },  // G5
      { freq: 1046.50, duration: 0.4 }, // C6
      { freq: 783.99, duration: 0.2 },  // G5
      { freq: 1046.50, duration: 0.6 }, // C6
    ];

    melody.forEach((note, index) => {
      setTimeout(() => {
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.frequency.setValueAtTime(note.freq, audioContext.currentTime);
        oscillator.type = 'sine';
        
        gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + note.duration);
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + note.duration);
      }, index * 250);
    });
  };

  const restartGame = () => {
    // 重新挑战：保留通关记录，返回首页重新开始
    router.push('/');
  };

  const shareSuccess = () => {
    // 分享功能
    if (navigator.share) {
      navigator.share({
        title: '小水滴勇闯沙漠',
        text: '我成功完成了小水滴勇闯沙漠的所有挑战，把沙漠变成了绿洲！',
        url: window.location.href,
      });
    } else {
      alert('太棒了！你成功完成了所有挑战！🎉');
    }
  };

  if (!mounted) return null;

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-500 via-green-600 to-emerald-700 relative overflow-hidden">
      {/* 彩带效果 */}
      {confettiActive && (
        <div className="fixed inset-0 pointer-events-none">
          {[...Array(50)].map((_, i) => (
            <div
              key={i}
              className="absolute animate-fall"
              style={{
                left: `${Math.random() * 100}%`,
                top: '-20px',
                animationDelay: `${Math.random() * 2}s`,
                animationDuration: `${2 + Math.random() * 3}s`,
              }}
            >
              <span className="text-2xl">{['🎉', '🎊', '⭐', '🌟', '✨'][Math.floor(Math.random() * 5)]}</span>
            </div>
          ))}
        </div>
      )}

      {/* 森林背景装饰 */}
      <div className="fixed bottom-0 left-0 right-0 pointer-events-none">
        <div className="flex justify-around items-end h-48 opacity-30">
          {[...Array(8)].map((_, i) => (
            <span key={i} className="text-6xl">🌲</span>
          ))}
        </div>
      </div>

      {/* 主要内容 */}
      <div className="container mx-auto px-4 py-12 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          
          {/* 奖杯图标 */}
          <div className="mb-8">
            <div className="text-9xl animate-bounce" style={{ animationDuration: '1s' }}>🏆</div>
          </div>

          {/* 恭喜标题 */}
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 drop-shadow-2xl">
            🎉 恭喜通关！🎉
          </h1>

          {/* 副标题 */}
          <p className="text-2xl md:text-3xl text-white mb-8 drop-shadow-lg">
            你成功帮助小水滴把沙漠变成了绿洲！
          </p>

          {/* 小水滴感谢 */}
          <div className="bg-white/20 backdrop-blur-sm rounded-3xl p-8 mb-8 border-4 border-white/30">
            <div className="text-8xl mb-4 animate-bounce">💧</div>
            <h2 className="text-3xl font-bold text-white mb-4">小水滴说：</h2>
            <p className="text-xl text-white leading-relaxed">
              "感谢大家的帮助！我们一起种下了70棵树，让这片沙漠变成了美丽的绿洲。
              我们不仅学习了水的科学知识，还学会了如何珍惜水资源，保护我们的地球家园！"
            </p>
          </div>

          {/* 成就统计 */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-6 border-4 border-white/30">
              <div className="text-5xl mb-2">🏔️</div>
              <div className="text-4xl font-bold text-white">7</div>
              <div className="text-lg text-white">完成关卡</div>
            </div>
            <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-6 border-4 border-white/30">
              <div className="text-5xl mb-2">📝</div>
              <div className="text-4xl font-bold text-white">73</div>
              <div className="text-lg text-white">答题挑战</div>
            </div>
            <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-6 border-4 border-white/30">
              <div className="text-5xl mb-2">🌳</div>
              <div className="text-4xl font-bold text-white">70</div>
              <div className="text-lg text-white">种下树木</div>
            </div>
          </div>

          {/* 森林展示 */}
          <div className="bg-white/20 backdrop-blur-sm rounded-3xl p-8 mb-8 border-4 border-white/30">
            <h3 className="text-2xl font-bold text-white mb-4">🌲 看看我们创造的绿洲 🌲</h3>
            <div className="flex flex-wrap justify-center gap-2">
              {[
                '🌲', '🌳', '🌴', '🌱', '🌿', '☘️', '🍀', 
                '🌲', '🌳', '🌴', '🌱', '🌿', '☘️', '🍀',
                '🌲', '🌳', '🌴', '🌱', '🌿', '☘️', '🍀',
                '🌲', '🌳', '🌴', '🌱', '🌿', '☘️', '🍀',
              ].map((tree, i) => (
                <span 
                  key={i} 
                  className="text-4xl animate-bounce" 
                  style={{ animationDelay: `${i * 0.05}s`, animationDuration: '0.6s' }}
                >
                  {tree}
                </span>
              ))}
            </div>
          </div>

          {/* 学习成果 */}
          <div className="bg-white/20 backdrop-blur-sm rounded-3xl p-8 mb-8 border-4 border-white/30 text-left">
            <h3 className="text-2xl font-bold text-white mb-4 text-center">📚 你学到了什么？</h3>
            <ul className="space-y-3 text-lg text-white">
              <li className="flex items-start gap-2">
                <span className="text-2xl">💧</span>
                <span>了解了水的三态变化：蒸发、凝结、凝固、熔化</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-2xl">🔥</span>
                <span>知道了温度对水的状态变化的影响</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-2xl">🧪</span>
                <span>学会了如何加快物质溶解的方法</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-2xl">🔬</span>
                <span>掌握了分离混合物的基本方法</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-2xl">♻️</span>
                <span>认识到了水在自然界中的循环过程</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-2xl">🌍</span>
                <span>学会了如何在生活中节约用水</span>
              </li>
            </ul>
          </div>

          {/* 操作按钮 */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              onClick={restartGame}
              size="lg"
              className="bg-white text-green-600 hover:bg-gray-100 px-8 py-6 text-xl font-bold"
            >
              <RotateCcw className="mr-2" />
              重新开始
            </Button>
            <Button
              onClick={shareSuccess}
              size="lg"
              variant="outline"
              className="bg-transparent text-white border-4 border-white hover:bg-white/20 px-8 py-6 text-xl font-bold"
            >
              <Share2 className="mr-2" />
              分享成就
            </Button>
          </div>

          {/* 温馨提示 */}
          <div className="mt-12 bg-white/10 backdrop-blur-sm rounded-2xl p-6 border-2 border-white/20">
            <p className="text-lg text-white">
              <Trophy className="inline-block w-6 h-6 mr-2" />
              感谢你陪伴小水滴完成这段精彩的旅程！
              <br />
              希望你能在日常生活中继续学习和探索科学知识，
              <br />
              用科学的方法解决问题，保护我们的地球家园！
            </p>
          </div>
        </div>
      </div>

      {/* 底部装饰 */}
      <div className="fixed bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-emerald-800 to-transparent pointer-events-none"></div>
    </div>
  );
}

// 添加自定义动画
if (typeof document !== 'undefined') {
  const style = document.createElement('style');
  style.textContent = `
    @keyframes fall {
      0% {
        transform: translateY(0) rotate(0deg);
        opacity: 1;
      }
      100% {
        transform: translateY(100vh) rotate(720deg);
        opacity: 0;
      }
    }
    
    .animate-fall {
      animation: fall linear forwards;
    }
  `;
  document.head.appendChild(style);
}
