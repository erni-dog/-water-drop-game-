'use client';

import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import CopyrightFooter from '@/components/CopyrightFooter';
import { ArrowLeft, CheckCircle2 } from 'lucide-react';
import { useEffect, useState } from 'react';

const LEVELS = [
  { id: 1, name: '水到哪里去了？', icon: '💧' },
  { id: 2, name: '水珠从哪里来？', icon: '☔' },
  { id: 3, name: '水沸腾了', icon: '♨️' },
  { id: 4, name: '水结冰了', icon: '🧊' },
  { id: 5, name: '冰融化了', icon: '🌊' },
  { id: 6, name: '水能溶解多少物质', icon: '🧪' },
  { id: 7, name: '加快溶解', icon: '⚡' },
  { id: 8, name: '用水分离', icon: '🔬' },
];

export default function LevelSelect() {
  const router = useRouter();
  const [completedLevels, setCompletedLevels] = useState<number[]>([]);
  const [mounted, setMounted] = useState(false);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    setMounted(true);
    
    // 检查登录状态
    const userData = localStorage.getItem('user');
    if (!userData) {
      router.push('/login?mode=game');
      return;
    }
    setUser(JSON.parse(userData));

    // 加载用户完成关卡
    try {
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      const currentUser = users.find((u: any) => u.username === JSON.parse(userData).username);
      if (currentUser && currentUser.completedLevels) {
        setCompletedLevels(currentUser.completedLevels);
      }
    } catch (e) {
      console.error('Failed to read localStorage:', e);
    }
  }, [router]);

  if (!mounted) return null;

  const handleLevelClick = (levelId: number) => {
    router.push(`/level/${levelId}`);
  };

  const handleRestart = (e: React.MouseEvent, levelId: number) => {
    e.stopPropagation(); // 阻止冒泡，避免触发点击关卡事件
    
    // 从用户的completedLevels中移除该关卡ID
    try {
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      const currentUser = users.find((u: any) => u.username === user?.username);
      
      if (currentUser && currentUser.completedLevels) {
        // 过滤掉要重新挑战的关卡ID
        currentUser.completedLevels = currentUser.completedLevels.filter((id: number) => id !== levelId);
        
        // 更新用户数据
        localStorage.setItem('users', JSON.stringify(users));
        
        // 更新本地状态
        setCompletedLevels(currentUser.completedLevels);
      }
    } catch (error) {
      console.error('Failed to restart level:', error);
    }
  };

  const allCompleted = completedLevels.length === 8;

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-300 via-yellow-200 to-orange-400 relative overflow-hidden flex flex-col">
      {/* 返回按钮 */}
      <div className="absolute top-6 left-6 z-20 flex gap-2">
        <Button
          onClick={() => router.push('/')}
          variant="outline"
          size="sm"
          className="bg-white/90 hover:bg-white shadow-lg"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          返回首页
        </Button>
        <Button
          onClick={() => {
            localStorage.removeItem('user');
            router.push('/');
          }}
          variant="outline"
          size="sm"
          className="bg-white/90 hover:bg-white text-red-600 shadow-lg"
        >
          退出登录
        </Button>
      </div>

      {/* 用户信息 */}
      <div className="absolute top-6 right-6 z-20">
        <div className="bg-white/90 rounded-xl px-4 py-2 shadow-lg">
          <span className="text-orange-900 font-semibold">👤 {user?.username}</span>
        </div>
      </div>

      {/* 标题 */}
      <div className="pt-24 pb-8 text-center">
        <h1 className="text-4xl md:text-5xl font-bold text-orange-900 drop-shadow-lg mb-2">
          选择关卡
        </h1>
        <p className="text-lg text-orange-800">帮助小水滴穿越8个挑战</p>
      </div>

      {/* 沙堆关卡网格 */}
      <div className="container mx-auto px-4 pb-24 flex-1">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 max-w-4xl mx-auto">
          {LEVELS.map((level) => {
            const isCompleted = completedLevels.includes(level.id);
            return (
              <div
                key={level.id}
                className="relative"
              >
                <button
                  onClick={() => handleLevelClick(level.id)}
                  className={`
                    w-full relative p-6 rounded-3xl shadow-2xl transform transition-all duration-300
                    hover:scale-105 hover:shadow-3xl
                    ${isCompleted 
                      ? 'bg-gradient-to-br from-green-400 to-green-600' 
                      : 'bg-gradient-to-br from-orange-400 to-orange-600'
                    }
                  `}
                >
                  {/* 沙堆形状装饰 */}
                  <div className={`absolute -top-2 left-1/2 transform -translate-x-1/2 w-16 h-8 rounded-t-full
                    ${isCompleted ? 'bg-green-300' : 'bg-orange-300'}
                  `}></div>
                  
                  {/* 关卡图标 */}
                  <div className="text-5xl mb-3 drop-shadow-md">{level.icon}</div>
                  
                  {/* 关卡名称 */}
                  <h3 className="text-white font-bold text-base md:text-lg mb-2 drop-shadow-sm text-center">
                    {level.name}
                  </h3>
                  
                  {/* 完成状态 */}
                  {isCompleted && (
                    <div className="absolute top-2 right-2">
                      <CheckCircle2 className="w-6 h-6 text-white" />
                    </div>
                  )}
                  
                  {/* 关卡编号 */}
                  <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2">
                    <span className="bg-white/30 px-3 py-1 rounded-full text-white text-sm font-semibold">
                      关卡 {level.id}
                    </span>
                  </div>
                </button>
                
                {/* 重新挑战按钮 */}
                {isCompleted && (
                  <button
                    onClick={(e) => handleRestart(e, level.id)}
                    className="absolute -bottom-3 left-1/2 transform -translate-x-1/2 
                             bg-white hover:bg-gray-100 text-orange-600 
                             px-4 py-1.5 rounded-full text-xs font-bold
                             shadow-lg transform transition-all duration-300
                             hover:scale-105 z-10"
                  >
                    🔄 重新挑战
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* 版权信息 */}
      <CopyrightFooter />

      {/* 装饰元素 */}
      <div className="absolute bottom-4 left-0 right-0 pointer-events-none opacity-20 z-0">
        <div className="flex justify-around text-5xl">
          <span>🌵</span>
          <span>🏜️</span>
          <span>🌵</span>
        </div>
      </div>
    </div>
  );
}
