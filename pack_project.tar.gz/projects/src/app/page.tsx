'use client';

import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import CopyrightFooter from '@/components/CopyrightFooter';
import { useEffect, useState } from 'react';
import { Droplet, Gamepad2, Settings, LogOut, User as UserIcon } from 'lucide-react';
import AuthDialog from '@/components/AuthDialog';

export default function Home() {
  const router = useRouter();
  const [mounted, setMounted] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [authDialogOpen, setAuthDialogOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');

  useEffect(() => {
    setMounted(true);
    // 检查登录状态
    const userData = localStorage.getItem('user');
    if (userData) {
      setUser(JSON.parse(userData));
    }
  }, []);

  const handleEnterGame = () => {
    if (user) {
      router.push('/level-select');
    } else {
      setAuthDialogOpen(true);
    }
  };

  const handleEnterAdmin = () => {
    if (user && user.role === 'admin') {
      router.push('/admin');
    } else {
      router.push('/login?mode=admin');
    }
  };

  const handleLogin = () => {
    setAuthMode('login');
    setAuthDialogOpen(true);
  };

  const handleRegister = () => {
    setAuthMode('register');
    setAuthDialogOpen(true);
  };

  const handleAuthSuccess = (userData: any) => {
    setUser(userData);
    setAuthDialogOpen(false);
  };

  const handleLogout = () => {
    localStorage.removeItem('user');
    setUser(null);
  };

  if (!mounted) return null;

  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-400 via-orange-300 to-yellow-200 relative overflow-hidden flex flex-col">
      {/* 沙漠背景装饰 */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-orange-200 to-transparent"></div>
      <div className="absolute bottom-10 left-10 w-40 h-20 bg-orange-300 rounded-full opacity-60 blur-sm"></div>
      <div className="absolute bottom-20 right-20 w-60 h-30 bg-orange-400 rounded-full opacity-50 blur-sm"></div>
      
      {/* 小标题 - 左上角 */}
      <div className="absolute top-8 left-8 z-10">
        <h2 className="text-lg font-bold text-white bg-blue-600 px-4 py-2 rounded-lg shadow-lg">
          三年级科学闯关游戏
        </h2>
      </div>

      {/* 右上角按钮 */}
      <div className="absolute top-8 right-8 z-10 flex gap-2">
        {user ? (
          <>
            {user.role === 'admin' && (
              <Button
                onClick={handleEnterAdmin}
                size="sm"
                variant="outline"
                className="bg-white/90 hover:bg-white text-blue-600 font-semibold border-2"
              >
                <Settings className="w-4 h-4 mr-2" />
                管理后台
              </Button>
            )}
            <Button
              onClick={handleLogout}
              size="sm"
              variant="outline"
              className="bg-white/90 hover:bg-white text-red-600 font-semibold border-2"
            >
              <LogOut className="w-4 h-4 mr-2" />
              退出
            </Button>
          </>
        ) : (
          <>
            <Button
              onClick={handleLogin}
              size="sm"
              variant="outline"
              className="bg-white/90 hover:bg-white text-blue-600 font-semibold border-2"
            >
              <UserIcon className="w-4 h-4 mr-2" />
              登录
            </Button>
            <Button
              onClick={handleRegister}
              size="sm"
              variant="outline"
              className="bg-white/90 hover:bg-white text-green-600 font-semibold border-2"
            >
              注册
            </Button>
            <Button
              onClick={handleEnterAdmin}
              size="sm"
              variant="outline"
              className="bg-white/90 hover:bg-white text-blue-600 font-semibold border-2"
              title="管理员登录"
            >
              <Settings className="w-4 h-4 mr-2" />
              管理后台
            </Button>
          </>
        )}
      </div>

      {/* 主要内容 */}
      <main className="flex flex-col items-center justify-center flex-1 px-4 pt-24 pb-32">
        {/* 水滴图标 */}
        <div className="mb-8 animate-bounce text-[120px] drop-shadow-lg">
          💧
        </div>

        {/* 大标题 */}
        <h1 className="text-6xl md:text-7xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-cyan-500 mb-8 text-center drop-shadow-xl">
          小水滴历险记
        </h1>

        {/* 副标题 */}
        <p className="text-xl md:text-2xl text-white mb-8 text-center max-w-2xl font-semibold drop-shadow-md">
          帮助小水滴穿越沙漠，把沙漠变成绿洲！
        </p>

        {/* 已登录：显示欢迎信息和进入游戏按钮 */}
        {user ? (
          <div className="w-full max-w-md space-y-6">
            {/* 用户欢迎卡片 */}
            <Card className="shadow-2xl border-2 border-blue-300">
              <CardContent className="pt-6">
                <div className="text-center space-y-4">
                  <div className="flex justify-center mb-3">
                    <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-green-500 rounded-full flex items-center justify-center shadow-lg">
                      <Gamepad2 className="w-8 h-8 text-white" />
                    </div>
                  </div>
                  <h3 className="text-2xl font-bold text-gray-800">
                    欢迎回来!
                  </h3>
                  <div className="text-lg text-blue-600 font-semibold">
                    👤 {user.username}
                  </div>
                  <div className="text-sm text-gray-500">
                    游戏次数: <span className="font-semibold">{getUserGamesCount(user.username)}</span>
                  </div>
                  <Button
                    onClick={handleEnterGame}
                    size="lg"
                    className="w-full h-14 text-xl font-bold bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 text-white shadow-xl transform hover:scale-105 transition-all duration-300"
                  >
                    🎮 进入游戏
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        ) : (
          /* 未登录：显示进入游戏按钮 */
          <div className="w-full max-w-md">
            <Button
              onClick={handleEnterGame}
              size="lg"
              className="w-full h-16 text-xl px-12 py-8 bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 text-white font-bold rounded-full shadow-2xl transform hover:scale-105 transition-all duration-300"
            >
              🎮 开始游戏
            </Button>
            <p className="text-center text-white mt-4 text-sm opacity-90">
              点击开始游戏或右上角登录/注册
            </p>
          </div>
        )}
      </main>

      {/* 版权信息 */}
      <CopyrightFooter />
      
      {/* 装饰元素 - 放在底部，增加底部间距 */}
      <div className="absolute bottom-4 flex gap-8 pointer-events-none opacity-30 z-0">
        <div className="text-5xl">🌵</div>
        <div className="text-5xl">☀️</div>
        <div className="text-5xl">🏜️</div>
      </div>

      {/* 登录/注册对话框 */}
      <AuthDialog 
        open={authDialogOpen} 
        onOpenChange={setAuthDialogOpen}
        mode={authMode}
        onSuccess={handleAuthSuccess}
      />
    </div>
  );
}

// 辅助函数：获取用户游戏次数
function getUserGamesCount(username: string): number {
  try {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const user = users.find((u: any) => u.username === username);
    return user?.totalGames || 0;
  } catch {
    return 0;
  }
}
