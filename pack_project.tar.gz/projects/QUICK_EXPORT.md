# 🎮 游戏快速导出指南

## 一键导出命令

### 方式1：本地测试导出
```bash
# 构建并启动生产服务器
pnpm build && pnpm start
```

访问：http://localhost:5000

---

## 📦 导出文件位置

构建完成后，生产文件位于：

```
.next/           # 构建输出目录
├── static/      # 静态资源
└── server/      # 服务端代码
```

---

## 🚀 推荐部署平台

### 1️⃣ Vercel（最简单）

1. 推送代码到 GitHub
2. 访问 https://vercel.com
3. 导入项目
4. 自动部署完成 ✅

**优点：** 免费、HTTPS、CDN、零配置

### 2️⃣ Netlify

1. 推送代码到 GitHub
2. 访问 https://netlify.com
3. 导入项目
4. 构建命令：`pnpm build`
5. 发布目录：留空（自动检测）

### 3️⃣ 传统服务器

#### 使用 PM2 运行
```bash
pnpm build
pnpm install -g pm2
pm2 start "pnpm start" --name water-drop-game
pm2 save
pm2 startup
```

#### 后台运行
```bash
pnpm build
nohup pnpm start > app.log 2>&1 &
```

---

## 🔧 常见问题

### Q: 端口被占用？
```bash
# 杀掉占用端口的进程
pkill -f "next-server"
# 或修改端口
PORT=3000 pnpm start
```

### Q: 构建失败？
```bash
# 清理缓存重新构建
rm -rf node_modules .next
pnpm install
pnpm build
```

### Q: 如何修改配置？
编辑 `next.config.js` 文件

---

## 📊 构建信息

- **构建时间：** 约5-10秒
- **输出大小：** 约2-5MB
- **运行端口：** 5000（可修改）
- **支持平台：** Linux/macOS/Windows

---

## ✅ 导出检查清单

- [ ] 运行 `pnpm build` 成功
- [ ] 运行 `pnpm start` 成功
- [ ] 访问 http://localhost:5000 正常
- [ ] 所有页面可访问
- [ ] 版权信息显示正常
- [ ] 游戏功能正常

---

**详细文档请查看：** `EXPORT_GUIDE.md`

**快速测试：**
```bash
pnpm build && pnpm start
# 浏览器访问 http://localhost:5000
```
