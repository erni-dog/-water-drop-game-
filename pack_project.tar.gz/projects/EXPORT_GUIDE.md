# 游戏导出指南

本指南介绍如何将"小水滴勇闯沙漠"游戏导出为可部署的生产版本。

## 📦 导出步骤

### 方法一：本地构建导出（推荐用于本地测试）

#### 1. 安装依赖
```bash
pnpm install
```

#### 2. 构建生产版本
```bash
pnpm build
```

**构建过程说明：**
- 安装所有依赖包
- 运行 TypeScript 类型检查
- 编译 Next.js 应用
- 优化和压缩代码
- 生成静态资源

#### 3. 启动生产服务器
```bash
pnpm start
```

**启动说明：**
- 在端口 5000 上启动生产服务器
- 使用 Next.js 内置的优化服务器
- 支持静态页面和服务端渲染

#### 4. 访问游戏
- 打开浏览器访问：`http://localhost:5000`
- 测试所有功能是否正常

---

### 方法二：导出静态文件（推荐用于部署到静态服务器）

#### 1. 修改配置（可选）

如果需要导出为纯静态文件，可以修改 `next.config.js`：

```javascript
/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export',  // 添加这一行
  images: {
    unoptimized: true,  // 如果有图片
  },
};

module.exports = nextConfig;
```

#### 2. 构建静态文件
```bash
pnpm build
```

#### 3. 导出位置
构建完成后，静态文件会生成在 `out/` 目录中。

#### 4. 部署
将 `out/` 目录中的所有文件上传到：
- GitHub Pages
- Vercel
- Netlify
- 任何静态文件服务器

---

### 方法三：使用 Docker 导出（推荐用于容器化部署）

#### 1. 创建 Dockerfile

在项目根目录创建 `Dockerfile`：

```dockerfile
# 使用官方 Node.js 镜像
FROM node:24-alpine AS base

# 安装依赖
FROM base AS deps
RUN apk add --no-cache libc6-compat
WORKDIR /app

COPY package.json pnpm-lock.yaml ./
RUN corepack enable pnpm && pnpm install --frozen-lockfile

# 构建应用
FROM base AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .

RUN corepack enable pnpm && pnpm build

# 生产运行
FROM base AS runner
WORKDIR /app

ENV NODE_ENV=production

RUN addgroup --system --gid 1001 nodejs
RUN adduser --system --uid 1001 nextjs

COPY --from=builder /app/public ./public
COPY --from=builder --chown=nextjs:nodejs /app/.next/standalone ./
COPY --from=builder --chown=nextjs:nodejs /app/.next/static ./.next/static

USER nextjs

EXPOSE 3000

ENV PORT=3000
ENV HOSTNAME="0.0.0.0"

CMD ["node", "server.js"]
```

#### 2. 修改 next.config.js

```javascript
/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'standalone',
};

module.exports = nextConfig;
```

#### 3. 构建镜像
```bash
docker build -t water-drop-game .
```

#### 4. 运行容器
```bash
docker run -p 3000:3000 water-drop-game
```

#### 5. 导出镜像
```bash
docker save water-drop-game > water-drop-game.tar
```

---

## 🚀 部署选项

### 1. Vercel（推荐）

1. 将代码推送到 GitHub
2. 访问 [vercel.com](https://vercel.com)
3. 导入项目
4. Vercel 会自动构建和部署

**优点：**
- 零配置部署
- 自动 HTTPS
- 全球 CDN
- 免费额度

### 2. Netlify

1. 将代码推送到 GitHub
2. 访问 [netlify.com](https://netlify.com)
3. 导入项目
4. 配置构建命令：`pnpm build`
5. 配置发布目录：`.next` 或 `out`

### 3. 传统服务器（Nginx）

#### 构建步骤：
```bash
pnpm build
pnpm start
```

#### 使用 PM2 保持运行：
```bash
pnpm install -g pm2
pm2 start "pnpm start" --name water-drop-game
pm2 save
pm2 startup
```

#### Nginx 配置示例：

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

---

## 📁 导出文件结构

构建完成后，生产文件结构：

```
workspace/
├── .next/              # Next.js 构建输出
│   ├── static/         # 静态资源
│   └── server/         # 服务端代码
├── public/             # 公共静态文件
│   ├── images/         # 图片资源
│   └── favicon.ico     # 网站图标
└── package.json        # 依赖配置
```

---

## 🔧 常见问题

### Q1: 构建失败怎么办？

**检查步骤：**
1. 确保 Node.js 版本为 24 或更高
2. 删除 `node_modules` 和 `.next` 目录：
   ```bash
   rm -rf node_modules .next
   pnpm install
   pnpm build
   ```
3. 检查 TypeScript 错误：
   ```bash
   pnpm ts-check
   ```

### Q2: 如何修改端口？

**方法一：修改环境变量**
```bash
PORT=3000 pnpm start
```

**方法二：修改脚本**
编辑 `scripts/start.sh`：
```bash
PORT=3000  # 修改这里
npx next start --port ${PORT}
```

### Q3: 如何添加自定义域名？

根据部署平台不同：

**Vercel：**
1. 进入项目设置
2. 添加域名
3. 配置 DNS

**Netlify：**
1. 进入 Site settings
2. 添加自定义域名
3. 配置 DNS

**传统服务器：**
在 Nginx 配置中添加域名监听。

### Q4: 如何优化构建速度？

1. 使用缓存：
   ```bash
   pnpm install --prefer-offline
   ```

2. 并行构建：
   ```bash
   # 在 next.config.js 中
   module.exports = {
     parallelServerBuilds: true,
   };
   ```

3. 减少依赖：
   - 移除未使用的包
   - 使用 tree-shaking

---

## 📊 性能优化建议

### 1. 启用压缩

在 `next.config.js` 中：
```javascript
module.exports = {
  compress: true,
};
```

### 2. 优化图片

使用 Next.js Image 组件：
```tsx
import Image from 'next/image';
<Image src="/logo.png" alt="Logo" width={200} height={200} />
```

### 3. 启用 CDN

- 使用 Vercel、Netlify 等平台的 CDN
- 或配置自己的 CDN（如 Cloudflare）

### 4. 缓存策略

```javascript
// next.config.js
module.exports = {
  headers: async () => [
    {
      source: '/:all*(svg|jpg|png)',
      locale: false,
      headers: [
        {
          key: 'Cache-Control',
          value: 'public, max-age=31536000, immutable',
        },
      ],
    },
  ],
};
```

---

## 📝 部署检查清单

导出前检查：

- [ ] 所有功能测试通过
- [ ] 环境变量配置正确
- [ ] 数据库连接正常（如果有）
- [ ] API 端点测试通过
- [ ] 版权信息已添加
- [ ] 版本号已更新
- [ ] 构建无错误
- [ ] 生产环境配置正确

---

## 🎯 快速导出命令

```bash
# 一键构建并启动
pnpm build && pnpm start

# 后台运行生产服务器
pnpm build && nohup pnpm start > /dev/null 2>&1 &

# 使用 PM2 运行
pnpm build && pm2 start "pnpm start" --name water-drop-game
```

---

## 📞 技术支持

如遇到问题，请检查：

1. **日志文件**：查看 `/app/work/logs/bypass/` 下的日志
2. **浏览器控制台**：F12 查看前端错误
3. **构建日志**：`pnpm build` 的输出信息

---

**祝您导出顺利！** 🎉
