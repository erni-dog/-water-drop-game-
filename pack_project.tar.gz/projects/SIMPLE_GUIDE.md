# 🎮 小水滴勇闯沙漠游戏 - 最简单部署指南

## 方案一：Vercel 部署（推荐，5分钟搞定）⭐

### 第一步：上传到 GitHub

1. 访问 https://github.com，登录或注册账号
2. 点击右上角 "+"，选择 "New repository"
3. 仓库名填：`water-drop-game`
4. 点击 "Create repository"

5. 在本地项目目录打开命令行，执行：

```bash
# 初始化 git
git init

# 添加所有文件
git add .

# 提交
git commit -m "小水滴勇闯沙漠游戏"

# 连接到 GitHub（替换为你的用户名）
git branch -M main
git remote add origin https://github.com/你的用户名/water-drop-game.git

# 推送代码
git push -u origin main
```

### 第二步：部署到 Vercel

1. 访问 https://vercel.com
2. 使用 GitHub 账号登录
3. 点击 "Add New" → "Project"
4. 找到你的 `water-drop-game` 仓库，点击 "Import"
5. 点击 "Deploy" 按钮
6. 等待 1-2 分钟，完成！✅

### 第三步：访问游戏

部署完成后，Vercel 会给你一个网址，例如：
```
https://water-drop-game.vercel.app
```

就是这个网址！直接分享给别人即可访问。

---

## 方案二：本地安装（需要 Node.js）

### 1. 安装 Node.js

访问 https://nodejs.org，下载并安装 LTS 版本（18.x 或 20.x）

### 2. 安装 pnpm

打开命令行，执行：
```bash
npm install -g pnpm
```

### 3. 复制项目文件

将整个项目文件夹复制到你想要的位置

### 4. 安装依赖

```bash
cd water-drop-game
pnpm install
```

### 5. 启动游戏

```bash
pnpm build && pnpm start
```

访问：http://localhost:5000

---

## 🎉 完成！

现在你的游戏已经可以运行了！

### 首页路径：
- 首页：`/`
- 登录页：`/login`
- 关卡选择：`/level-select`
- 游戏关卡：`/level/1` 到 `/level/8`
- 通关页：`/game-complete`

### 版权信息
游戏底部已添加版权信息，包含：
- 作者信息
- CC BY-NC-SA 4.0 许可协议
- 版本号

---

## ❓ 遇到问题？

### Vercel 部署失败？
- 确保代码已推送到 GitHub
- 检查 `package.json` 中的 `scripts` 配置是否正确
- 查看 Vercel 部署日志

### 本地运行失败？
- 确认 Node.js 版本 >= 18
- 删除 `node_modules` 和 `.next`，重新 `pnpm install`
- 检查端口 5000 是否被占用

### 更多帮助
- 查看 `EXPORT_GUIDE.md` 获取详细说明
- 查看 `QUICK_EXPORT.md` 获取快速参考

---

**祝游戏运行顺利！** 🎮✨
