# 🎮 小水滴勇闯沙漠游戏 - 下载说明

## 📦 下载文件

游戏已打包为：**`water-drop-game.tar.gz`**（大小：7.5MB）

---

## 📥 如何下载

### 方法一：直接下载（如果有下载链接）
1. 点击下载按钮
2. 保存 `water-drop-game.tar.gz` 到任意位置
3. 跳到"安装步骤"

### 方法二：从服务器下载

**如果您有服务器访问权限：**

```bash
# 1. 进入项目目录
cd /workspace/projects

# 2. 下载压缩包
# 使用 wget
wget http://你的服务器IP/water-drop-game.tar.gz

# 或使用 curl
curl -O http://你的服务器IP/water-drop-game.tar.gz

# 3. 确认下载成功
ls -lh water-drop-game.tar.gz
```

**如果您的服务器在 Vercel 或其他平台：**
- 登录平台
- 下载项目源码
- 直接导入项目（无需下载压缩包）

---

## 🔧 安装步骤

### Windows 用户

#### 方式 A：使用自动安装脚本（推荐）

1. **解压压缩包**
   - 右键点击 `water-drop-game.tar.gz`
   - 选择"解压到当前文件夹"
   - 解压后会得到 `water-drop-game` 文件夹

2. **运行安装脚本**
   - 进入 `water-drop-game` 文件夹
   - 双击 `install.bat`
   - 如果提示权限问题，右键选择"以管理员身份运行"
   - 等待安装完成（约 2-5 分钟）

3. **访问游戏**
   - 安装完成后，浏览器会自动打开游戏
   - 或手动访问：http://localhost:5000

#### 方式 B：手动安装

1. **解压压缩包**
   - 右键点击 `water-drop-game.tar.gz`
   - 选择"解压到当前文件夹"

2. **安装 Node.js**
   - 访问：https://nodejs.org
   - 下载并安装 LTS 版本（推荐 20.x）

3. **打开命令行**
   - 在 `water-drop-game` 文件夹中，按住 Shift + 右键
   - 选择"在此处打开 PowerShell 窗口"

4. **安装并启动**
   ```bash
   # 安装依赖
   pnpm install

   # 构建并启动
   pnpm build && pnpm start
   ```

5. **访问游戏**
   - 打开浏览器访问：http://localhost:5000

---

### Mac 用户

#### 方式 A：使用自动安装脚本（推荐）

1. **解压压缩包**
   - 双击 `water-drop-game.tar.gz`
   - 解压后会得到 `water-drop-game` 文件夹

2. **运行安装脚本**
   - 打开终端（Terminal）
   - 进入 `water-drop-game` 文件夹：
     ```bash
     cd ~/Downloads/water-drop-game
     ```
   - 运行安装脚本：
     ```bash
     ./install.sh
     ```
   - 等待安装完成

3. **访问游戏**
   - 安装完成后，浏览器会自动打开游戏
   - 或手动访问：http://localhost:5000

#### 方式 B：手动安装

1. **解压压缩包**
   - 双击 `water-drop-game.tar.gz`

2. **安装 Node.js（如果未安装）**
   ```bash
   # 使用 Homebrew 安装
   brew install node
   ```

3. **打开终端并进入游戏目录**
   ```bash
   cd ~/Downloads/water-drop-game
   ```

4. **安装并启动**
   ```bash
   # 安装依赖
   pnpm install

   # 构建并启动
   pnpm build && pnpm start
   ```

5. **访问游戏**
   - 打开浏览器访问：http://localhost:5000

---

### Linux 用户

#### 方式 A：使用自动安装脚本（推荐）

1. **解压压缩包**
   ```bash
   tar -xzf water-drop-game.tar.gz
   ```

2. **运行安装脚本**
   ```bash
   cd water-drop-game
   chmod +x install.sh
   ./install.sh
   ```

3. **访问游戏**
   - 浏览器访问：http://localhost:5000

#### 方式 B：手动安装

1. **解压压缩包**
   ```bash
   tar -xzf water-drop-game.tar.gz
   ```

2. **安装 Node.js（如果未安装）**
   ```bash
   # Ubuntu/Debian
   curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
   sudo apt-get install -y nodejs
   ```

3. **安装并启动**
   ```bash
   cd water-drop-game
   pnpm install
   pnpm build && pnpm start
   ```

4. **访问游戏**
   - 浏览器访问：http://localhost:5000

---

## 🎯 快速开始（命令行）

如果您熟悉命令行，可以快速执行：

**Windows (PowerShell):**
```powershell
pnpm install && pnpm build && pnpm start
```

**Mac/Linux:**
```bash
pnpm install && pnpm build && pnpm start
```

然后访问：**http://localhost:5000**

---

## ✅ 验证安装成功

1. **访问游戏**
   - 打开浏览器
   - 访问 http://localhost:5000
   - 应该能看到游戏首页

2. **测试游戏**
   - 点击"开始游戏"
   - 输入昵称
   - 选择关卡
   - 尝试答题

3. **检查所有页面**
   - 首页：`/`
   - 登录页：`/login`
   - 关卡选择：`/level-select`
   - 游戏关卡：`/level/1` ~ `/level/8`
   - 通关页：`/game-complete`

---

## ❓ 常见问题

### Q: 解压时提示"未知格式"？

**A:** 需要安装支持 tar.gz 的解压软件：
- Windows：7-Zip、WinRAR
- Mac：内置支持
- Linux：内置支持

---

### Q: 运行 install.bat 时提示"不是内部或外部命令"？

**A:** 需要先安装 Node.js：
1. 访问 https://nodejs.org
2. 下载并安装 LTS 版本

---

### Q: 安装时提示"pnpm: command not found"？

**A:** 手动安装 pnpm：
```bash
npm install -g pnpm
```

---

### Q: 提示"端口 5000 已被占用"？

**A:** 使用其他端口：
```bash
# Windows
set PORT=3000 && pnpm start

# Mac/Linux
PORT=3000 pnpm start
```

然后访问：http://localhost:3000

---

### Q: 浏览器打开后显示空白？

**A:** 检查游戏是否启动：
```bash
# 查看进程
pm2 status

# 或直接在命令行查看输出
pnpm start
```

---

## 📖 更多文档

- `README_INSTALL.md` - 详细安装指南
- `SIMPLE_GUIDE.md` - 简单部署指南
- `EXPORT_GUIDE.md` - 详细导出方案

---

## 🎮 游戏说明

**游戏特色：**
- 8 个科学知识关卡
- 趣味选择题
- 帮助小水滴将沙漠变成绿洲

**知识点：**
- 水的三态变化
- 溶解现象
- 水的净化
- 水的循环

---

## 💡 提示

- 首次运行需要构建，请耐心等待 1-2 分钟
- 推荐使用 Chrome 浏览器
- 游戏支持响应式设计，可在手机和平板上运行
- 需要保持命令行窗口打开才能继续运行游戏

---

**祝您游戏愉快！** 🎮✨
