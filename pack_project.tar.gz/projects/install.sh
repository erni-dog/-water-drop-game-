#!/bin/bash

# 设置颜色
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo "========================================"
echo "   🎮 小水滴勇闯沙漠游戏 - 安装脚本"
echo "========================================"
echo ""

# 检查 Node.js
echo "[1/5] 检查 Node.js 安装..."
if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ 未检测到 Node.js${NC}"
    echo ""
    echo "请先安装 Node.js:"
    echo ""
    echo "Mac:"
    echo "  brew install node"
    echo ""
    echo "Linux (Ubuntu/Debian):"
    echo "  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -"
    echo "  sudo apt-get install -y nodejs"
    echo ""
    exit 1
fi

NODE_VER=$(node --version)
echo -e "${GREEN}✓${NC} Node.js 版本: $NODE_VER"
echo ""

# 检查 pnpm
echo "[2/5] 检查 pnpm 安装..."
if ! command -v pnpm &> /dev/null; then
    echo "pnpm 未安装，正在安装..."
    npm install -g pnpm
    if [ $? -ne 0 ]; then
        echo -e "${RED}❌ pnpm 安装失败${NC}"
        echo "请检查网络连接后重试"
        exit 1
    fi
fi

PNPM_VER=$(pnpm --version)
echo -e "${GREEN}✓${NC} pnpm 版本: $PNPM_VER"
echo ""

# 安装依赖
echo "[3/5] 正在安装游戏依赖..."
echo -e "${YELLOW}这可能需要 1-3 分钟，请耐心等待...${NC}"
echo ""
pnpm install
if [ $? -ne 0 ]; then
    echo ""
    echo -e "${RED}❌ 依赖安装失败${NC}"
    echo "请检查网络连接后重试"
    exit 1
fi
echo ""
echo -e "${GREEN}✓${NC} 依赖安装完成"
echo ""

# 构建
echo "[4/5] 正在构建游戏..."
echo -e "${YELLOW}这可能需要 10-20 秒...${NC}"
echo ""
pnpm build
if [ $? -ne 0 ]; then
    echo ""
    echo -e "${RED}❌ 构建失败${NC}"
    echo "请尝试删除 .next 文件夹后重试"
    exit 1
fi
echo ""
echo -e "${GREEN}✓${NC} 构建完成"
echo ""

# 启动游戏
echo "[5/5] 正在启动游戏..."
echo ""
echo "========================================"
echo -e "${GREEN}🎉 安装成功！${NC}"
echo "========================================"
echo ""
echo "游戏已启动"
echo "请在浏览器中访问: ${GREEN}http://localhost:5000${NC}"
echo ""
echo "提示:"
echo "  - 按 Ctrl+C 停止游戏"
echo "  - 关闭终端会停止游戏"
echo ""

# 尝试自动打开浏览器
if [[ "$OSTYPE" == "darwin"* ]]; then
    # Mac
    echo "正在打开浏览器..."
    open http://localhost:5000
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    # Linux
    echo "正在打开浏览器..."
    xdg-open http://localhost:5000 2>/dev/null || echo "请手动在浏览器中打开 http://localhost:5000"
fi

echo ""
echo "正在启动游戏服务器..."
echo ""

# 启动游戏
pnpm start
